/**
 * M2y v2 - Sistema de Logging Estruturado
 */

export const LogLevel = {
  NORMAL: 'NORMAL',
  TRACE: 'TRACE',
  DEBUG: 'DEBUG',
  INFO: 'INFO',
  WARNING: 'WARNING',
  ERROR: 'ERROR'
};

export const LogEvent = {
  EXECUTION_STARTED: 'execution_started',
  PARAMETERS_LOADED: 'parameters_loaded',
  PAGE_ACCESSED: 'page_accessed',
  LEAD_EXTRACTED: 'lead_extracted',
  SCREENSHOT_CAPTURED: 'screenshot_captured',
  DELAY_STARTED: 'delay_started',
  DELAY_FINISHED: 'delay_finished',
  ERROR_OCCURRED: 'error_occurred',
  BLOCKING_DETECTED: 'blocking_detected',
  EXECUTION_FINISHED: 'execution_finished',
  EXECUTION_PAUSED: 'EXECUTION_PAUSED',
  EXECUTION_RESUMED: 'EXECUTION_RESUMED',
  EXECUTION_STOPPING: 'EXECUTION_STOPPING',
  EXECUTION_STOPPED: 'EXECUTION_STOPPED',
  EXECUTION_COMPLETED: 'EXECUTION_COMPLETED',
  EXECUTION_FAILED: 'EXECUTION_FAILED',
  EXTERNAL_SEARCH_STARTED: 'EXTERNAL_SEARCH_STARTED',
  EXTERNAL_SEARCH_COMPLETED: 'EXTERNAL_SEARCH_COMPLETED',
  EXTERNAL_SEARCH_FAILED: 'EXTERNAL_SEARCH_FAILED',
  TIMEOUT: 'TIMEOUT',
  SELECTOR_FAILURE: 'SELECTOR_FAILURE'
};

class Logger {
  constructor() {
    this.logs = [];
    this.executionId = null;
    this.mode = 'NORMAL';
    this.maxLogs = 5000;
  }

  init(executionId) {
    this.executionId = executionId;
    this.logs = [];
  }

  setMode(mode = 'NORMAL') { this.mode = ['NORMAL', 'INFO', 'DEBUG', 'TRACE'].includes(mode) ? mode : 'NORMAL'; }

  log(level, event, details = {}) {
    if (this.mode === 'NORMAL' && (level === LogLevel.DEBUG || level === LogLevel.TRACE)) return;
    const logEntry = {
      timestamp: new Date().toISOString(),
      module: details.module || 'service-worker',
      level,
      executionId: this.executionId,
      leadId: details.leadId || details.id || null,
      event,
      message: details.message || event,
      error: details.error || null,
      details
    };
    
    this.logs.push(logEntry);
    if (this.logs.length > this.maxLogs) this.logs = this.logs.slice(-this.maxLogs);
    
    // Salvar logs periodicamente no storage para não perder em caso de crash
    this.persistLogs();
  }

  async persistLogs() {
    if (!this.executionId) return;
    const key = `logs_${this.executionId}`;
    await chrome.storage.local.set({ [key]: this.logs.slice(-this.maxLogs) });
  }

  getLogs() {
    return this.logs;
  }

  async clearLogs(executionId) {
    const key = `logs_${executionId}`;
    await chrome.storage.local.remove(key);
  }
}

const logger = new Logger();
export default logger;
