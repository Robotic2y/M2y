const storageApi = () => globalThis.chrome?.storage?.local;
import DataQuality from './data-quality.js';
const getAll = async () => { const api = storageApi(); return api ? api.get(null) : {}; };
const get = async key => { const api = storageApi(); return api ? api.get(key) : {}; };
const set = async value => { const api = storageApi(); return api ? api.set(value) : undefined; };
const remove = async keys => { const api = storageApi(); return api ? api.remove(keys) : undefined; };

export const StorageRepository = {
  async settingsGet() { return (await get('m2y_settings')).m2y_settings || {}; },
  async settingsSet(value) { return set({ m2y_settings: { ...(await this.settingsGet()), ...value, schemaVersion: 3 } }); },
  async executionGet(id) { const key = `leads_${id}`; const data = await get(key); return Array.isArray(data[key]) ? data[key] : []; },
  async executionSet(id, leads) { return set({ [`leads_${id}`]: Array.isArray(leads) ? leads : [] }); },
  async executionRemove(id) { return remove([`leads_${id}`, `logs_${id}`, `metrics_${id}`]); },
  async identityIndexGet() { return (await get('m2y_lead_index')).m2y_lead_index || {}; },
  async identityIndexSet(index) { return set({ m2y_lead_index: { ...(index || {}), schemaVersion: 1, updatedAt: new Date().toISOString() } }); },
  async cacheGet(namespace) { const key = `m2y_cache_${namespace}`; return (await get(key))[key] || null; },
  async cacheSet(namespace, value) { return set({ [`m2y_cache_${namespace}`]: { ...value, schemaVersion: 1 } }); },
  async cacheDelete(namespace) { return remove(`m2y_cache_${namespace}`); },
  async migrate() {
    const data = await getAll(); const updates = {}; let migratedLeads = 0;
    if (!data.m2y_schema_version) updates.m2y_schema_version = 3;
    if (data.globalDeduplicationCache && !data.m2y_lead_index) updates.m2y_lead_index = { schemaVersion: 1, migratedFrom: 'globalDeduplicationCache', updatedAt: new Date().toISOString() };
    for (const [key, rows] of Object.entries(data)) {
      if (!key.startsWith('leads_') || !Array.isArray(rows)) continue;
      let changed = false;
      const migrated = rows.map(lead => {
        if (lead?.schemaVersion >= 3 && lead?.dataVersion) return lead;
        migratedLeads++; changed = true;
        return { ...DataQuality.enrichLead(lead || {}), schemaVersion: 3, dataVersion: '2.15', migratedAt: new Date().toISOString() };
      });
      if (changed) updates[key] = migrated;
    }
    if (Object.keys(updates).length) await set(updates);
    return { schemaVersion: 3, migrated: Object.keys(updates).length > 0, migratedLeads };
  }
};
export default StorageRepository;
