/**
 * M2y v2 - Utilitários
 */

export const sleep = (ms) => new Promise(resolve => setTimeout(resolve, ms));

export const generateUUID = () => {
  return 'xxxxxxxx-xxxx-4xxx-yxxx-xxxxxxxxxxxx'.replace(/[xy]/g, function(c) {
    var r = Math.random() * 16 | 0, v = c == 'x' ? r : (r & 0x3 | 0x8);
    return v.toString(16);
  });
};

export const formatTimestamp = (date = new Date()) => {
  return date.toISOString().replace(/T/, ' ').replace(/\..+/, '');
};

export const validateLead = (lead) => {
  // Regras de validação: nome é obrigatório
  return !!(lead.name && lead.name !== 'N/A');
};

export const calculateCompleteness = (lead) => {
  const fields = ['name', 'phone', 'website', 'address', 'category'];
  const filled = fields.filter(f => lead[f] && lead[f] !== 'N/A' && lead[f] !== '').length;
  return (filled / fields.length) * 100;
};

export const generateHash = (str) => {
  let hash = 0;
  for (let i = 0; i < str.length; i++) {
    const char = str.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash |= 0; // Convert to 32bit integer
  }
  return Math.abs(hash).toString(16);
};

export const getLeadUniqueId = (lead) => {
  // 1. Tentar extrair Place ID da URL
  let placeId = null;
  if (lead.google_maps_url) {
    const match = lead.google_maps_url.match(/!1s([^!]+)/);
    if (match && match[1]) {
      placeId = match[1];
    }
  }

  // 2. Criar hash secundário (nome + endereço + telefone)
  const rawString = `${lead.name || ''}|${lead.address || ''}|${lead.phone || ''}`.toLowerCase().replace(/\s+/g, '');
  const secondaryHash = generateHash(rawString);

  // 3. Combinar (Place ID como prioridade)
  return placeId ? `pid_${placeId}` : `hash_${secondaryHash}`;
};
