const DB_NAME = 'm2y_media';
const STORE = 'screenshots';
const openDb = () => new Promise((resolve, reject) => {
  if (typeof indexedDB === 'undefined') return reject(new Error('INDEXEDDB_UNAVAILABLE'));
  const request = indexedDB.open(DB_NAME, 1);
  request.onupgradeneeded = () => request.result.createObjectStore(STORE, { keyPath: 'id' });
  request.onsuccess = () => resolve(request.result); request.onerror = () => reject(request.error || new Error('INDEXEDDB_OPEN_FAILED'));
});
const storage = () => globalThis.chrome?.storage?.local;
const hash = async value => { if (!globalThis.crypto?.subtle) return String(value).slice(0, 80); const bytes = new TextEncoder().encode(String(value)); const out = await crypto.subtle.digest('SHA-256', bytes); return [...new Uint8Array(out)].map(b => b.toString(16).padStart(2, '0')).join(''); };
const toBlob = dataUrl => { const [head, body] = String(dataUrl).split(','); const binary = atob(body || ''); const bytes = new Uint8Array(binary.length); for (let i = 0; i < binary.length; i += 1) bytes[i] = binary.charCodeAt(i); return new Blob([bytes], { type: head.match(/data:([^;]+)/)?.[1] || 'image/jpeg' }); };
export async function save(dataUrl, metadata = {}) {
  const screenshotHash = await hash(dataUrl); const id = metadata.id || `ss_${Date.now()}_${Math.random().toString(36).slice(2, 8)}`;
  try {
    const local = storage(); const indexData = local ? await local.get('m2y_screenshot_hash_index') : {}; const index = indexData?.m2y_screenshot_hash_index || {};
    if (index[screenshotHash]) return index[screenshotHash];
    const db = await openDb(); await new Promise((resolve, reject) => { const tx = db.transaction(STORE, 'readwrite'); tx.objectStore(STORE).put({ id, blob: toBlob(dataUrl), hash: screenshotHash, status: 'captured', ...metadata, createdAt: new Date().toISOString() }); tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); });
    if (local) await local.set({ m2y_screenshot_hash_index: { ...index, [screenshotHash]: id } });
    return id;
  } catch (_) { return null; }
}
export async function get(id) {
  try { const db = await openDb(); return await new Promise((resolve, reject) => { const req = db.transaction(STORE).objectStore(STORE).get(id); req.onsuccess = () => resolve(req.result || null); req.onerror = () => reject(req.error); }); } catch (_) { return null; }
}
export async function remove(id) { try { const db = await openDb(); await new Promise((resolve, reject) => { const tx = db.transaction(STORE, 'readwrite'); tx.objectStore(STORE).delete(id); tx.oncomplete = resolve; tx.onerror = () => reject(tx.error); }); return true; } catch (_) { return false; } }
export const ScreenshotStore = { save, get, remove };
export default ScreenshotStore;
