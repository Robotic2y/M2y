export const EXECUTION_STATES = Object.freeze({
  IDLE: 'idle', STARTING: 'starting', RUNNING: 'running', PAUSED: 'paused',
  STOPPING: 'stopping', STOPPED: 'stopped', COMPLETED: 'completed', FAILED: 'failed'
});

const TERMINAL = new Set([EXECUTION_STATES.STOPPED, EXECUTION_STATES.COMPLETED, EXECUTION_STATES.FAILED]);
const ACTIVE = new Set([EXECUTION_STATES.STARTING, EXECUTION_STATES.RUNNING, EXECUTION_STATES.PAUSED, EXECUTION_STATES.STOPPING]);
const TRANSITIONS = {
  idle: new Set(['starting']), starting: new Set(['running', 'failed', 'stopping']),
  running: new Set(['paused', 'stopping', 'completed', 'failed']),
  paused: new Set(['running', 'stopping', 'failed']), stopping: new Set(['stopped', 'failed']),
  stopped: new Set(), completed: new Set(), failed: new Set()
};

export class ExecutionManager {
  constructor({ storage = null, storageKey = 'm2y_active_execution' } = {}) {
    this.storage = storage;
    this.storageKey = storageKey;
    this.state = { id: null, status: EXECUTION_STATES.IDLE };
  }
  snapshot() { return { ...this.state }; }
  getCurrent() { return this.snapshot(); }
  isLocked() { return ACTIVE.has(this.state.status); }
  isTerminal(status = this.state.status) { return TERMINAL.has(status); }
  canTransition(next) { return Boolean(TRANSITIONS[this.state.status]?.has(next)); }
  create(payload = {}) {
    if (this.isLocked()) {
      const error = new Error('EXTRACTION_ALREADY_RUNNING');
      error.code = 'EXTRACTION_ALREADY_RUNNING';
      throw error;
    }
    this.state = { id: payload.id || null, ...payload, status: EXECUTION_STATES.STARTING,
      startedAt: payload.startedAt || new Date().toISOString(), finishedAt: null,
      durationMs: null, reason: null, error: null, recoveryStatus: null };
    return this.snapshot();
  }
  transition(next, patch = {}) {
    if (this.isTerminal() || this.state.status === next) return false;
    if (!this.canTransition(next)) {
      const error = new Error(`INVALID_EXECUTION_TRANSITION:${this.state.status}->${next}`);
      error.code = 'INVALID_EXECUTION_TRANSITION';
      throw error;
    }
    this.state = { ...this.state, ...patch, status: next };
    if (TERMINAL.has(next)) {
      this.state.finishedAt = this.state.finishedAt || new Date().toISOString();
      this.state.durationMs = Math.max(0, Date.parse(this.state.finishedAt) - Date.parse(this.state.startedAt || this.state.finishedAt));
    }
    return true;
  }
  async persist(state = this.state) {
    if (this.storage?.set && state?.id) await this.storage.set({ [this.storageKey]: { ...state } });
    return this.snapshot();
  }
  async restore() {
    if (!this.storage?.get) return null;
    const stored = await this.storage.get(this.storageKey);
    const recovered = stored?.[this.storageKey];
    if (!recovered?.id) return null;
    this.state = { ...this.state, ...recovered };
    if (ACTIVE.has(this.state.status)) this.state.recoveryStatus = 'recoverable';
    return this.snapshot();
  }
  async clear() { if (this.storage?.remove) await this.storage.remove(this.storageKey); }
}

export { TERMINAL, ACTIVE };
export default ExecutionManager;
