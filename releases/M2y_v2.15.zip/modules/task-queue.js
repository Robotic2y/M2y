const PRIORITY = Object.freeze({ critical: 0, high: 1, normal: 2, low: 3 });
const sleep = ms => new Promise(resolve => setTimeout(resolve, ms));
export class TaskQueue {
  constructor({ concurrency = 2, maxQueue = 1000, retryLimit = 2, defaultTimeout = 30000 } = {}) { this.concurrency = Math.max(1, Number(concurrency)); this.maxQueue = maxQueue; this.retryLimit = retryLimit; this.defaultTimeout = defaultTimeout; this.queue = []; this.active = 0; this.paused = false; this.stopped = false; this.sequence = 0; }
  add(task, options = {}) {
    if (this.stopped) return Promise.reject(Object.assign(new Error('QUEUE_STOPPED'), { code: 'QUEUE_STOPPED', classification: 'user_action_required' }));
    if (this.queue.length >= this.maxQueue) return Promise.reject(Object.assign(new Error('QUEUE_BACKPRESSURE'), { code: 'QUEUE_BACKPRESSURE', classification: 'recoverable' }));
    return new Promise((resolve, reject) => { this.queue.push({ id: options.id || `task_${Date.now()}_${this.sequence}`, task, priority: PRIORITY[options.priority] ?? PRIORITY.normal, timeout: options.timeout || this.defaultTimeout, retries: 0, resolve, reject, sequence: this.sequence++ }); this.pump(); });
  }
  pump() { if (this.paused || this.stopped) return; while (this.active < this.concurrency && this.queue.length) { this.queue.sort((a,b) => a.priority - b.priority || a.sequence - b.sequence); const item = this.queue.shift(); this.active++; this.run(item).finally(() => { this.active--; this.pump(); }); } }
  async run(item) {
    while (!this.stopped) { try { const result = await Promise.race([Promise.resolve().then(() => item.task({ id: item.id, attempt: item.retries + 1 })), new Promise((_, reject) => setTimeout(() => reject(Object.assign(new Error('TASK_TIMEOUT'), { code: 'TASK_TIMEOUT', classification: 'retryable' })), item.timeout))]); item.resolve(result); return; } catch (error) { const retryable = error?.classification === 'retryable' || ['ETIMEDOUT','TASK_TIMEOUT','NETWORK_ERROR'].includes(error?.code); if (!retryable || item.retries >= this.retryLimit) { item.reject(error); return; } item.retries++; await sleep(Math.min(2000 * item.retries, 8000)); } }
    item.reject(Object.assign(new Error('QUEUE_STOPPED'), { code: 'QUEUE_STOPPED', classification: 'user_action_required' }));
  }
  pause() { this.paused = true; }
  resume() { this.paused = false; this.pump(); }
  cancel(id) { const index = this.queue.findIndex(item => item.id === id); if (index < 0) return false; const [item] = this.queue.splice(index, 1); item.reject(Object.assign(new Error('TASK_CANCELLED'), { code: 'TASK_CANCELLED', classification: 'user_action_required' })); return true; }
  stop() { this.stopped = true; const pending = this.queue.splice(0); pending.forEach(item => item.reject(Object.assign(new Error('QUEUE_STOPPED'), { code: 'QUEUE_STOPPED', classification: 'user_action_required' }))); }
  resumeAfterStop() { this.stopped = false; this.paused = false; this.pump(); }
  getStats() { return { queued: this.queue.length, active: this.active, paused: this.paused, stopped: this.stopped, concurrency: this.concurrency }; }
}
export default TaskQueue;
