const UF = new Set('AC AL AP AM BA CE DF ES GO MA MT MS MG PA PB PR PE PI RJ RN RS RO RR SC SP SE TO'.split(' '));
const CEP = /\b\d{5}-?\d{3}\b/;
export function parseAddress(address = '') {
  const raw = String(address || '').trim();
  if (!raw || raw === 'N/A') return { raw, street: 'N/A', number: 'N/A', complement: 'N/A', neighborhood: 'N/A', city: 'N/A', state: 'N/A', cep: 'N/A', country: 'Brasil', confidence: 0 };
  const parts = raw.split(',').map(x => x.trim()).filter(Boolean);
  const result = { raw, street: parts[0] || 'N/A', number: 'N/A', complement: 'N/A', neighborhood: 'N/A', city: 'N/A', state: 'N/A', cep: (raw.match(CEP)?.[0] || 'N/A'), country: 'Brasil', confidence: 20 };
  const first = parts[0] || '';
  const numberMatch = first.match(/\b(\d+[A-Za-z]?)\b/) || String(parts[1] || '').match(/^\s*(\d+[A-Za-z]?)\s*$/);
  if (numberMatch) { result.number = numberMatch[1]; result.street = first.slice(0, numberMatch.index).trim() || first; result.confidence += 15; }
  const ufIndex = parts.findIndex(p => UF.has(p.toUpperCase()) || /[-/ ]([A-Z]{2})\b/.test(p));
  if (ufIndex >= 0) {
    const statePart = parts[ufIndex]; const match = statePart.match(/(?:^|[-/ ])([A-Z]{2})\b/i);
    result.state = (match?.[1] || statePart).toUpperCase(); if (!UF.has(result.state)) result.state = 'N/A';
    const cityPart = statePart.split(/[-/]/)[0].trim(); if (cityPart && !UF.has(cityPart.toUpperCase())) result.city = cityPart;
    if (result.city === 'N/A' && ufIndex > 0) result.city = parts[ufIndex - 1].replace(/\b\d{5}-?\d{3}\b/, '').trim() || 'N/A';
    result.confidence += 35;
  } else if (parts.length >= 2) {
    result.city = parts[parts.length - 1].replace(CEP, '').trim() || 'N/A'; result.confidence += 10;
  }
  if (parts.length >= 3) result.neighborhood = result.number !== 'N/A' ? (parts[2] || 'N/A') : (parts[1] || 'N/A');
  if (parts.length >= 4) result.complement = result.number !== 'N/A' ? (parts[2] || 'N/A') : (parts[2] || 'N/A');
  if (result.cep !== 'N/A') result.confidence += 15;
  return result;
}
export const AddressParser = { parse: parseAddress };
export default AddressParser;
