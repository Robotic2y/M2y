const filled = (lead, key) => Boolean(lead?.[key] && lead[key] !== 'N/A');
export function qualityScore(lead = {}) {
  const weights = { name: 10, category_main: 10, address: 10, phone: 15, website: 15, hours: 10, rating_value: 10, screenshot: 15, digital_presence: 5 };
  const earned = Object.entries(weights).reduce((sum, [key, weight]) => sum + (filled(lead, key) ? weight : 0), 0);
  return Math.round(earned / Object.values(weights).reduce((a, b) => a + b, 0) * 100);
}
export function digitalPresenceScore(lead = {}) {
  const factors = [filled(lead, 'website'), filled(lead, 'social_instagram'), filled(lead, 'social_facebook'), filled(lead, 'social_linkedin'), Array.isArray(lead.social_others) && lead.social_others.length > 0, filled(lead, 'google_business_url')];
  return Math.round(factors.filter(Boolean).length / factors.length * 100);
}
export function commercialScore(lead = {}) {
  const factors = [filled(lead, 'phone'), filled(lead, 'website'), filled(lead, 'digital_presence'), Number(lead.reviews_count || lead.reviews || 0) >= 10, Number(lead.rating_value || 0) >= 4, filled(lead, 'address'), filled(lead, 'category_main')];
  return Math.round(factors.filter(Boolean).length / factors.length * 100);
}
export const LeadScores = { qualityScore, commercialScore, digitalPresenceScore };
export default LeadScores;
