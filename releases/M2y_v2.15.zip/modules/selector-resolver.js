export function firstMatch(root, selectors = []) {
  for (const selector of selectors) {
    try { const node = root?.querySelector(selector); if (node) return node; } catch (_) {}
  }
  return null;
}
export function allMatches(root, selectors = []) {
  const seen = new Set(); const result = [];
  for (const selector of selectors) {
    try { root?.querySelectorAll(selector).forEach(node => { if (!seen.has(node)) { seen.add(node); result.push(node); } }); } catch (_) {}
  }
  return result;
}
export const SelectorResolver = { firstMatch, allMatches };
export default SelectorResolver;
