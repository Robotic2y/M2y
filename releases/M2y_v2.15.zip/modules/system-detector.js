/**
 * M2y v2.11 - Módulo de Detecção de Sistema e Hardware
 * ============================================================
 * Funcionalidades:
 * - Detecção automática do sistema operacional (Windows, macOS, Linux, Android, iOS)
 * - Detecção de arquitetura (32/64 bits)
 * - Estimativa de memória disponível
 * - Informações de CPU (núcleos lógicos)
 * - Heurística de recomendação de modo de extração
 * - Persistência de preferência do usuário (override manual)
 * - Sugestão automática baseada em hardware
 * ============================================================
 */

// ============================================================
// CONSTANTES DE SISTEMA OPERACIONAL
// ============================================================

export const OS_TYPES = {
  WINDOWS:  'windows',
  MACOS:    'macos',
  LINUX:    'linux',
  ANDROID:  'android',
  IOS:      'ios',
  CHROMEOS: 'chromeos',
  UNKNOWN:  'unknown'
};

export const OS_LABELS = {
  [OS_TYPES.WINDOWS]:  'Windows',
  [OS_TYPES.MACOS]:    'macOS',
  [OS_TYPES.LINUX]:    'Linux',
  [OS_TYPES.ANDROID]:  'Android',
  [OS_TYPES.IOS]:      'iOS',
  [OS_TYPES.CHROMEOS]: 'Chrome OS',
  [OS_TYPES.UNKNOWN]:  'Desconhecido'
};

export const OS_ICONS = {
  [OS_TYPES.WINDOWS]:  '🪟',
  [OS_TYPES.MACOS]:    '🍎',
  [OS_TYPES.LINUX]:    '🐧',
  [OS_TYPES.ANDROID]:  '🤖',
  [OS_TYPES.IOS]:      '📱',
  [OS_TYPES.CHROMEOS]: '🌐',
  [OS_TYPES.UNKNOWN]:  '💻'
};

// ============================================================
// DETECÇÃO DE SISTEMA OPERACIONAL
// ============================================================

/**
 * Detecta o sistema operacional atual com base no User Agent e platform
 * @returns {{os: string, arch: string, version: string, isMobile: boolean}}
 */
export function detectOS() {
  const ua = navigator.userAgent || '';
  const platform = navigator.platform || '';

  let os = OS_TYPES.UNKNOWN;
  let arch = 'unknown';
  let version = '';
  let isMobile = false;

  // Android (deve vir antes de Linux)
  if (/Android/i.test(ua)) {
    os = OS_TYPES.ANDROID;
    isMobile = true;
    const match = ua.match(/Android\s([\d.]+)/i);
    if (match) version = match[1];
    arch = ua.includes('x86_64') || ua.includes('x64') ? '64bit' : '32bit';
  }
  // iOS (iPhone/iPad)
  else if (/iPhone|iPad|iPod/i.test(ua)) {
    os = OS_TYPES.IOS;
    isMobile = true;
    const match = ua.match(/OS\s([\d_]+)/i);
    if (match) version = match[1].replace(/_/g, '.');
    arch = '64bit'; // Todos os iOS modernos são 64bit
  }
  // Chrome OS
  else if (/CrOS/i.test(ua)) {
    os = OS_TYPES.CHROMEOS;
    arch = ua.includes('x86_64') ? '64bit' : '32bit';
  }
  // macOS
  else if (/Macintosh|Mac OS X|MacIntel|MacPPC/i.test(ua) || /Mac/i.test(platform)) {
    os = OS_TYPES.MACOS;
    const match = ua.match(/Mac OS X\s([\d_.]+)/i);
    if (match) version = match[1].replace(/_/g, '.');
    // Macs modernos são todos 64bit
    arch = '64bit';
    // Detectar Apple Silicon (ARM)
    if (ua.includes('Apple Silicon') || (platform === 'MacIntel' && navigator.maxTouchPoints > 1)) {
      arch = '64bit-arm';
    }
  }
  // Windows
  else if (/Win/i.test(ua) || /Win/i.test(platform)) {
    os = OS_TYPES.WINDOWS;
    if (/Windows NT 10\.0/i.test(ua)) version = '10/11';
    else if (/Windows NT 6\.3/i.test(ua)) version = '8.1';
    else if (/Windows NT 6\.2/i.test(ua)) version = '8';
    else if (/Windows NT 6\.1/i.test(ua)) version = '7';
    else if (/Windows NT 6\.0/i.test(ua)) version = 'Vista';
    else if (/Windows NT 5\.1/i.test(ua)) version = 'XP';

    // Detectar arquitetura Windows
    if (ua.includes('WOW64') || ua.includes('Win64') || ua.includes('x64')) {
      arch = '64bit';
    } else if (ua.includes('x86')) {
      arch = '32bit';
    } else {
      arch = '64bit'; // Assumir 64bit para Windows modernos
    }
  }
  // Linux
  else if (/Linux/i.test(ua) || /Linux/i.test(platform)) {
    os = OS_TYPES.LINUX;
    arch = ua.includes('x86_64') || ua.includes('x64') ? '64bit' : '32bit';
    // Detectar distros específicas
    if (/Ubuntu/i.test(ua)) version = 'Ubuntu';
    else if (/Fedora/i.test(ua)) version = 'Fedora';
    else if (/Debian/i.test(ua)) version = 'Debian';
    else if (/Arch/i.test(ua)) version = 'Arch';
  }

  return { os, arch, version, isMobile };
}

// ============================================================
// DETECÇÃO DE HARDWARE
// ============================================================

/**
 * Obtém informações de hardware disponíveis via APIs do navegador
 * @returns {Promise<HardwareInfo>}
 */
export async function detectHardware() {
  const info = {
    cpuCores:     navigator.hardwareConcurrency || null,
    memoryGB:     null,
    memoryClass:  'unknown',
    deviceMemory: null,
    connection:   null,
    isLowEnd:     false,
    isMidRange:   false,
    isHighEnd:    false
  };

  // Memória do dispositivo (API experimental, disponível no Chrome)
  if (navigator.deviceMemory) {
    info.deviceMemory = navigator.deviceMemory; // GB (valores: 0.25, 0.5, 1, 2, 4, 8)
    info.memoryGB = navigator.deviceMemory;
  }

  // Tentar obter memória via performance.memory (Chrome)
  try {
    if (performance && performance.memory) {
      const totalMB = performance.memory.jsHeapSizeLimit / (1024 * 1024);
      // Estimar RAM total a partir do heap limit (heurística)
      if (totalMB < 512)       info.memoryGB = info.memoryGB || 2;
      else if (totalMB < 1024) info.memoryGB = info.memoryGB || 4;
      else if (totalMB < 2048) info.memoryGB = info.memoryGB || 8;
      else                     info.memoryGB = info.memoryGB || 16;
    }
  } catch (e) { /* silencioso */ }

  // Informações de conexão
  if (navigator.connection) {
    info.connection = {
      type:        navigator.connection.effectiveType || 'unknown',
      downlink:    navigator.connection.downlink || null,
      rtt:         navigator.connection.rtt || null,
      saveData:    navigator.connection.saveData || false
    };
  }

  // Classificar o dispositivo
  const cores = info.cpuCores || 4;
  const mem   = info.memoryGB || 4;

  if (cores <= 2 || mem <= 2) {
    info.isLowEnd   = true;
    info.memoryClass = 'low';
  } else if (cores <= 4 || mem <= 4) {
    info.isMidRange  = true;
    info.memoryClass = 'mid';
  } else {
    info.isHighEnd   = true;
    info.memoryClass = 'high';
  }

  return info;
}

// ============================================================
// HEURÍSTICA DE RECOMENDAÇÃO
// ============================================================

/**
 * Gera recomendação de modo de extração baseada no hardware e SO
 * @param {Object} osInfo - Resultado de detectOS()
 * @param {Object} hwInfo - Resultado de detectHardware()
 * @returns {Recommendation}
 */
export function generateRecommendation(osInfo, hwInfo) {
  const rec = {
    speedMode:        'balanced',
    stealthMode:      true,
    randomUserAgent:  false,
    delayMin:         2,
    delayMax:         5,
    maxLeads:         50,
    maxScrollAttempts: 50,
    reasons:          [],
    warnings:         [],
    score:            100 // Score de compatibilidade (0-100)
  };

  // ---- Análise de OS ----
  if (osInfo.isMobile) {
    rec.speedMode = 'safe';
    rec.delayMin  = 4;
    rec.delayMax  = 8;
    rec.maxLeads  = 30;
    rec.score    -= 20;
    rec.warnings.push('Dispositivo móvel detectado — modo seguro ativado automaticamente');
  }

  if (osInfo.os === OS_TYPES.LINUX) {
    rec.reasons.push('Linux: excelente compatibilidade e estabilidade');
    rec.score += 5;
  } else if (osInfo.os === OS_TYPES.MACOS) {
    rec.reasons.push('macOS: boa compatibilidade com Chrome');
    rec.score += 3;
  } else if (osInfo.os === OS_TYPES.WINDOWS) {
    rec.reasons.push('Windows: compatibilidade total');
  } else if (osInfo.os === OS_TYPES.CHROMEOS) {
    rec.reasons.push('Chrome OS: ambiente nativo para extensões Chrome');
    rec.score += 5;
  }

  // ---- Análise de Hardware ----
  if (hwInfo.isLowEnd) {
    rec.speedMode         = 'safe';
    rec.delayMin          = 3;
    rec.delayMax          = 7;
    rec.maxLeads          = 30;
    rec.maxScrollAttempts = 30;
    rec.score            -= 25;
    rec.warnings.push(`Hardware limitado (${hwInfo.cpuCores || '?'} núcleos, ~${hwInfo.memoryGB || '?'} GB RAM) — modo seguro recomendado`);
    rec.reasons.push('Delays aumentados para evitar travamentos');
  } else if (hwInfo.isMidRange) {
    rec.speedMode = 'balanced';
    rec.reasons.push(`Hardware médio (${hwInfo.cpuCores || '?'} núcleos, ~${hwInfo.memoryGB || '?'} GB RAM) — modo balanceado`);
  } else if (hwInfo.isHighEnd) {
    rec.speedMode         = 'balanced'; // Ainda balanceado para anti-bloqueio
    rec.maxLeads          = 100;
    rec.maxScrollAttempts = 80;
    rec.reasons.push(`Hardware potente (${hwInfo.cpuCores || '?'} núcleos, ~${hwInfo.memoryGB || '?'} GB RAM) — pode usar modo agressivo`);
    rec.score += 10;
  }

  // ---- Análise de Conexão ----
  if (hwInfo.connection) {
    if (hwInfo.connection.saveData) {
      rec.speedMode = 'safe';
      rec.warnings.push('Modo economia de dados ativo — velocidade reduzida');
      rec.score -= 10;
    }
    if (hwInfo.connection.type === '2g' || hwInfo.connection.type === 'slow-2g') {
      rec.speedMode = 'safe';
      rec.delayMin  = 5;
      rec.delayMax  = 10;
      rec.score    -= 30;
      rec.warnings.push('Conexão lenta detectada (2G) — delays aumentados');
    } else if (hwInfo.connection.type === '3g') {
      rec.score -= 10;
      rec.warnings.push('Conexão 3G detectada — performance pode ser afetada');
    } else if (hwInfo.connection.type === '4g' || hwInfo.connection.type === 'wifi') {
      rec.reasons.push('Conexão rápida — ótima para extração');
      rec.score += 5;
    }
  }

  // Garantir score dentro dos limites
  rec.score = Math.max(0, Math.min(100, rec.score));

  return rec;
}

// ============================================================
// PERSISTÊNCIA DE PREFERÊNCIAS
// ============================================================

const PREF_KEY = 'm2y_system_prefs';

/**
 * Salva as preferências do usuário (override manual)
 * @param {Object} prefs
 */
export async function saveSystemPrefs(prefs) {
  try {
    await chrome.storage.local.set({ [PREF_KEY]: prefs });
  } catch (e) {
    // Fallback para localStorage
    localStorage.setItem(PREF_KEY, JSON.stringify(prefs));
  }
}

/**
 * Carrega as preferências salvas do usuário
 * @returns {Promise<Object|null>}
 */
export async function loadSystemPrefs() {
  try {
    const data = await chrome.storage.local.get(PREF_KEY);
    return data[PREF_KEY] || null;
  } catch (e) {
    try {
      const raw = localStorage.getItem(PREF_KEY);
      return raw ? JSON.parse(raw) : null;
    } catch (e2) {
      return null;
    }
  }
}

/**
 * Limpa as preferências salvas (resetar para detecção automática)
 */
export async function clearSystemPrefs() {
  try {
    await chrome.storage.local.remove(PREF_KEY);
  } catch (e) {
    localStorage.removeItem(PREF_KEY);
  }
}

// ============================================================
// FUNÇÃO PRINCIPAL — ANÁLISE COMPLETA DO SISTEMA
// ============================================================

/**
 * Executa análise completa do sistema e retorna todas as informações
 * @param {boolean} [useCache=true] - Usar cache se disponível
 * @returns {Promise<SystemAnalysis>}
 */
export async function analyzeSystem(useCache = true) {
  // Verificar preferências salvas (override manual)
  const savedPrefs = await loadSystemPrefs();

  const osInfo = detectOS();
  const hwInfo = await detectHardware();
  const recommendation = generateRecommendation(osInfo, hwInfo);

  // Se o usuário tem preferências salvas, mesclar com a recomendação
  const finalConfig = savedPrefs
    ? { ...recommendation, ...savedPrefs, isOverridden: true }
    : { ...recommendation, isOverridden: false };

  return {
    os:             osInfo,
    hardware:       hwInfo,
    recommendation: finalConfig,
    savedPrefs,
    timestamp:      new Date().toISOString()
  };
}

/**
 * Formata o relatório do sistema para exibição no popup
 * @param {SystemAnalysis} analysis
 * @returns {string}
 */
export function formatSystemReport(analysis) {
  const { os, hardware, recommendation } = analysis;
  const osLabel = OS_LABELS[os.os] || 'Desconhecido';
  const osIcon  = OS_ICONS[os.os] || '💻';

  const lines = [
    `${osIcon} ${osLabel}${os.version ? ` ${os.version}` : ''} (${os.arch})`,
    `🔲 CPU: ${hardware.cpuCores || '?'} núcleos`,
    `💾 RAM: ~${hardware.memoryGB || '?'} GB`,
  ];

  if (hardware.connection) {
    lines.push(`🌐 Conexão: ${hardware.connection.type || 'desconhecida'}`);
  }

  lines.push(`⚡ Score: ${recommendation.score}/100`);

  if (recommendation.isOverridden) {
    lines.push(`⚙️ Modo: Manual (override ativo)`);
  } else {
    const modeLabel = { safe: 'Seguro', balanced: 'Balanceado', aggressive: 'Agressivo' };
    lines.push(`🎯 Recomendado: ${modeLabel[recommendation.speedMode] || recommendation.speedMode}`);
  }

  return lines.join('\n');
}

/**
 * Retorna os modos de SO disponíveis para seleção manual
 * @returns {Array<{value: string, label: string, icon: string}>}
 */
export function getOSOptions() {
  return Object.entries(OS_TYPES)
    .filter(([, v]) => v !== OS_TYPES.UNKNOWN)
    .map(([, v]) => ({
      value: v,
      label: OS_LABELS[v],
      icon:  OS_ICONS[v]
    }));
}

export default {
  detectOS,
  detectHardware,
  generateRecommendation,
  analyzeSystem,
  formatSystemReport,
  saveSystemPrefs,
  loadSystemPrefs,
  clearSystemPrefs,
  getOSOptions,
  OS_TYPES,
  OS_LABELS,
  OS_ICONS
};
