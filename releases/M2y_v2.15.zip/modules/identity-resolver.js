const PLACE_ID = /(?:!1s|place_id[=:])([^!&/]+)/i;
const CID = /(?:cid=|0x[0-9a-f]+:0x)([0-9a-f]+)/i;

export function normalizeText(value = '') {
  return String(value || '').normalize('NFD').replace(/[\u0300-\u036f]/g, '').toLowerCase().replace(/[^a-z0-9]+/g, ' ').trim();
}
export function normalizePhone(value = '') {
  const digits = String(value || '').replace(/\D/g, '');
  return digits.length >= 8 ? digits : '';
}
export function normalizeWebsite(value = '') {
  try {
    if (!value || value === 'N/A') return '';
    const url = new URL(/^https?:\/\//i.test(value) ? value : `https://${value}`);
    return `${url.hostname.toLowerCase().replace(/^www\./, '')}${url.pathname.replace(/\/$/, '')}`;
  } catch (_) { return normalizeText(value); }
}
export function normalizeName(value = '') { return normalizeText(value); }
export function normalizeAddress(value = '') { return normalizeText(value).replace(/\b(rua|r|avenida|av)\b/g, '').trim(); }
export function createIdentityHash(parts = []) {
  const raw = parts.join('|'); let hash = 2166136261;
  for (let i = 0; i < raw.length; i += 1) { hash ^= raw.charCodeAt(i); hash = Math.imul(hash, 16777619); }
  return `hash_${(hash >>> 0).toString(16).padStart(8, '0')}`;
}
export function resolve(lead = {}, url = lead.google_maps_url || '') {
  const place = String(url).match(PLACE_ID)?.[1] || lead.place_id || lead.placeId;
  if (place) return { primary: `place_${normalizeText(place).replace(/ /g, '_')}`, keys: [`place_${normalizeText(place).replace(/ /g, '_')}`], source: 'place_id' };
  const cid = String(url).match(CID)?.[1] || lead.cid;
  if (cid) return { primary: `cid_${cid.toLowerCase()}`, keys: [`cid_${cid.toLowerCase()}`], source: 'cid' };
  const canonicalUrl = normalizeWebsite(url);
  const phone = normalizePhone(lead.phone);
  const website = normalizeWebsite(lead.website);
  const name = normalizeName(lead.name);
  const address = normalizeAddress(lead.address);
  const keys = [];
  if (canonicalUrl) keys.push(`url_${canonicalUrl}`);
  if (phone) keys.push(`phone_${phone}`);
  if (website) keys.push(`web_${website}`);
  if (name && address) keys.push(`profile_${name}_${address}`);
  const hash = createIdentityHash([name, address, phone, website]);
  keys.push(hash);
  return { primary: keys[0] || hash, keys, source: keys[0]?.split('_')[0] || 'hash' };
}
export const IdentityResolver = { normalizeText, normalizePhone, normalizeWebsite, normalizeName, normalizeAddress, createIdentityHash, resolve };
export default IdentityResolver;
