/**
 * M2y v2 - Sistema de Métricas de Performance
 */

class Metrics {
  constructor() {
    this.reset();
  }

  reset() {
    this.executionId = null;
    this.startTime = null;
    this.endTime = null;
    this.totalRequests = 0;
    this.errorRequests = 0;
    this.validLeads = 0;
    this.incompleteLeads = 0;
    this.responseTimes = [];
    this.estimatedTotal = 0;
    this.lastUpdateTime = null;
    this.lastLeadCount = 0;
    this.currentSpeed = 0; // leads per minute
    this.funnel = {
      cardsFound: 0,
      cardsProcessed: 0,
      validLeads: 0,
      accepted: 0,
      filtered: 0,
      duplicates: 0,
      errors: 0,
      screenshotFailures: 0,
      timeouts: 0
    };
  }

  start(executionId, estimatedTotal = 0) {
    this.reset();
    this.executionId = executionId;
    this.startTime = Date.now();
    this.lastUpdateTime = this.startTime;
    this.estimatedTotal = estimatedTotal;
  }

  end() {
    this.endTime = Date.now();
  }

  addRequest(success = true, responseTime = 0) {
    this.totalRequests++;
    if (!success) this.errorRequests++;
    if (responseTime > 0) this.responseTimes.push(responseTime);
  }

  addLead(isValid = true) {
    if (isValid) this.validLeads++;
    else this.incompleteLeads++;
    
    this.updateSpeed();
  }

  record(stage, amount = 1) {
    if (Object.prototype.hasOwnProperty.call(this.funnel, stage)) {
      this.funnel[stage] += Math.max(0, Number(amount) || 0);
    }
  }

  updateSpeed() {
    const now = Date.now();
    const totalLeads = this.validLeads + this.incompleteLeads;
    const elapsedMinutes = (now - this.startTime) / 60000;
    
    if (elapsedMinutes > 0) {
      this.currentSpeed = totalLeads / elapsedMinutes;
    }
  }

  setEstimatedTotal(total) {
    this.estimatedTotal = total;
  }

  getSummary() {
    const now = Date.now();
    const duration = this.endTime ? (this.endTime - this.startTime) / 1000 : (now - this.startTime) / 1000;
    const totalLeads = this.validLeads + this.incompleteLeads;
    const avgResponseTime = this.responseTimes.length > 0 
      ? this.responseTimes.reduce((a, b) => a + b, 0) / this.responseTimes.length 
      : 0;

    // Cálculo de progresso e estimativas
    const targetLeads = this.estimatedTotal || 0;
    const progressPercent = targetLeads > 0 ? Math.min(100, (totalLeads / targetLeads) * 100) : 0;
    
    // Estimativa de tempo restante (ETA)
    let etaSeconds = 0;
    if (this.currentSpeed > 0 && targetLeads > totalLeads) {
      const remainingLeads = targetLeads - totalLeads;
      etaSeconds = (remainingLeads / this.currentSpeed) * 60;
    }

    return {
      executionId: this.executionId,
      durationSeconds: duration,
      totalLeads,
      validLeads: this.validLeads,
      incompleteLeads: this.incompleteLeads,
      successRate: this.totalRequests > 0 ? ((this.totalRequests - this.errorRequests) / this.totalRequests) * 100 : 100,
      avgTimePerLead: totalLeads > 0 ? duration / totalLeads : 0,
      avgResponseTimeMs: avgResponseTime,
      speedLpm: this.currentSpeed,
      progressPercent,
      etaSeconds,
      estimatedTotal: targetLeads
      ,funnel: { ...this.funnel },
      acceptanceRate: this.funnel.cardsProcessed ? (this.funnel.accepted / this.funnel.cardsProcessed) * 100 : 0,
      duplicateRate: this.funnel.cardsProcessed ? (this.funnel.duplicates / this.funnel.cardsProcessed) * 100 : 0,
      errorRate: this.funnel.cardsProcessed ? (this.funnel.errors / this.funnel.cardsProcessed) * 100 : 0,
      completeDataRate: this.funnel.accepted ? (this.funnel.validLeads / this.funnel.accepted) * 100 : 0
    };
  }

  async persist(executionId) {
    const key = `metrics_${executionId}`;
    await chrome.storage.local.set({ [key]: this.getSummary() });
  }
}

const metrics = new Metrics();
export default metrics;
