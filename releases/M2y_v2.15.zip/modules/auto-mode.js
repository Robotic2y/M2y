/**
 * M2y v2.11 - Módulo Auto Inteligente
 * ============================================================
 * O Modo Auto Inteligente decide automaticamente:
 * - Raio ideal de busca baseado na densidade urbana da cidade
 * - Granularidade da busca (simples vs. expandida)
 * - Volume de resultados esperado
 * - Estratégia de extração (rápida, balanceada, profunda)
 * - Filtros implícitos baseados na categoria
 *
 * Heurísticas utilizadas:
 * - Tamanho da cidade (capital, grande, média, pequena)
 * - Tipo de categoria (serviço local, varejo, saúde, etc.)
 * - Densidade estimada de estabelecimentos
 * - Histórico de extrações anteriores
 * ============================================================
 */

// ============================================================
// CLASSIFICAÇÃO DE CIDADES POR PORTE
// ============================================================

/** Cidades com população estimada > 500.000 */
const GRANDES_CIDADES = new Set([
  'São Paulo', 'Rio de Janeiro', 'Brasília', 'Salvador', 'Fortaleza',
  'Belo Horizonte', 'Manaus', 'Curitiba', 'Recife', 'Porto Alegre',
  'Belém', 'Goiânia', 'Guarulhos', 'Campinas', 'São Luís',
  'São Gonçalo', 'Maceió', 'Duque de Caxias', 'Natal', 'Teresina',
  'Campo Grande', 'Nova Iguaçu', 'São Bernardo do Campo', 'João Pessoa',
  'Osasco', 'Jaboatão dos Guararapes', 'Contagem', 'Ribeirão Preto',
  'Uberlândia', 'Sorocaba', 'Aracaju', 'Feira de Santana', 'Cuiabá',
  'Joinville', 'Juiz de Fora', 'Londrina', 'Aparecida de Goiânia',
  'Ananindeua', 'Porto Velho', 'Serra', 'Caxias do Sul', 'Macapá',
  'Mogi das Cruzes', 'São João de Meriti', 'Florianópolis', 'Betim',
  'Niterói', 'Santos', 'Diadema', 'Caucaia', 'Maringá'
]);

/** Cidades com população estimada 100k-500k */
const CIDADES_MEDIAS = new Set([
  'Campina Grande', 'Vitória', 'Pelotas', 'Caruaru', 'Montes Claros',
  'Anápolis', 'Blumenau', 'Ponta Grossa', 'Cascavel', 'Piracicaba',
  'Petrolina', 'Juazeiro do Norte', 'Mossoró', 'Marabá', 'Santarém',
  'Imperatriz', 'Vitória da Conquista', 'Jundiaí', 'Bauru', 'Canoas',
  'Olinda', 'Camaçari', 'Franca', 'Ilhéus', 'Foz do Iguaçu',
  'Paulista', 'São José dos Campos', 'Lauro de Freitas', 'Parauapebas',
  'Gravataí', 'Viamão', 'Novo Hamburgo', 'São Leopoldo', 'Chapecó',
  'Criciúma', 'Itajaí', 'Palmas', 'Araguaína', 'Porto Nacional',
  'Ji-Paraná', 'Ariquemes', 'Boa Vista', 'Macaé', 'Campos dos Goytacazes',
  'Volta Redonda', 'Petrópolis', 'Angra dos Reis', 'Cabo Frio',
  'Governador Valadares', 'Ipatinga', 'Sete Lagoas', 'Divinópolis',
  'Uberaba', 'Montes Claros', 'Teófilo Otoni', 'Poços de Caldas',
  'Barbacena', 'Varginha', 'Passos', 'Pouso Alegre', 'Itabira',
  'Rondonópolis', 'Sinop', 'Lucas do Rio Verde', 'Várzea Grande',
  'Dourados', 'Três Lagoas', 'Corumbá', 'Parnaíba', 'Picos',
  'Timon', 'Caxias', 'Barreiras', 'Jequié', 'Alagoinhas',
  'Itabuna', 'Feira de Santana', 'Paulo Afonso', 'Teixeira de Freitas',
  'Sobral', 'Maracanaú', 'Crato', 'Iguatu', 'Quixadá',
  'Coari', 'Itacoatiara', 'Parintins', 'Tefé', 'Tabatinga',
  'Santana', 'Laranjal do Jari', 'Oiapoque', 'Cruzeiro do Sul',
  'Rio Branco', 'Arapiraca', 'Rio Largo', 'Palmeira dos Índios',
  'Nossa Senhora do Socorro', 'Lagarto', 'Itabaiana', 'Estância',
  'Gurupi', 'Araguaína', 'Paraíso do Tocantins', 'Guaraí',
  'São José dos Pinhais', 'Pinhais', 'Colombo', 'Almirante Tamandaré',
  'Araucária', 'Piraquara', 'Fazenda Rio Grande', 'São José dos Pinhais',
  'Umuarama', 'Maringá', 'Apucarana', 'Guarapuava', 'Toledo',
  'Paranaguá', 'Ponta Grossa', 'Foz do Iguaçu', 'Cascavel',
  'Santa Maria', 'Pelotas', 'Caxias do Sul', 'Canoas', 'Gravataí',
  'Viamão', 'Novo Hamburgo', 'São Leopoldo', 'Alvorada', 'Cachoeirinha',
  'Blumenau', 'Joinville', 'Florianópolis', 'Itajaí', 'Criciúma',
  'Chapecó', 'Lages', 'Jaraguá do Sul', 'São José', 'Palhoça',
  'Araraquara', 'Araçatuba', 'Presidente Prudente', 'Marília', 'Bauru',
  'São José do Rio Preto', 'Ribeirão Preto', 'Franca', 'Piracicaba',
  'Sorocaba', 'Jundiaí', 'Mogi das Cruzes', 'Taubaté', 'São Vicente',
  'Praia Grande', 'Guarujá', 'Cubatão', 'Caçapava', 'Jacareí',
  'Limeira', 'Americana', 'Sumaré', 'Hortolândia', 'Santa Bárbara d\'Oeste',
  'Indaiatuba', 'Valinhos', 'Vinhedo', 'Itatiba', 'Bragança Paulista',
  'Atibaia', 'Mogi Guaçu', 'Mogi Mirim', 'Amparo', 'Itapira'
]);

// ============================================================
// PERFIS DE CATEGORIA
// ============================================================

/**
 * Perfis de categoria definem o comportamento padrão do Auto Mode
 * para diferentes tipos de estabelecimentos
 */
const CATEGORY_PROFILES = {
  // Serviços locais de alta densidade
  alimentacao: {
    keywords: ['restaurante', 'padaria', 'lanchonete', 'pizzaria', 'bar', 'cafe', 'sorveteria', 'confeitaria', 'hamburgueria', 'sushi', 'churrascaria', 'delivery', 'food truck', 'bistrô', 'choperia', 'cervejaria', 'doceria', 'brigaderia', 'pastelaria', 'rotisserie', 'marmitaria'],
    defaultRadius: 5,
    densityFactor: 1.5,
    expectedLeads: 50,
    strategy: 'balanced',
    implicitFilters: { filterPhone: true, ignoreDuplicates: true },
    searchGranularity: 'medium'
  },
  saude: {
    keywords: ['clinica', 'hospital', 'dentista', 'medico', 'farmacia', 'laboratorio', 'psicologo', 'fisioterapeuta', 'nutricionista', 'veterinario', 'otica', 'drogaria', 'ortopedista', 'cardiologista', 'dermatologista', 'pediatra', 'ginecologista', 'neurologista'],
    defaultRadius: 10,
    densityFactor: 0.8,
    expectedLeads: 30,
    strategy: 'safe',
    implicitFilters: { filterPhone: true, ignoreDuplicates: true, minRating: 3.5 },
    searchGranularity: 'deep'
  },
  beleza: {
    keywords: ['salao', 'barbearia', 'manicure', 'estetica', 'spa', 'cabeleireiro', 'barbeiro', 'nail', 'tatuagem', 'depilacao', 'bronzeamento', 'maquiagem', 'micropigmentacao'],
    defaultRadius: 5,
    densityFactor: 1.2,
    expectedLeads: 40,
    strategy: 'balanced',
    implicitFilters: { filterPhone: true, ignoreDuplicates: true },
    searchGranularity: 'medium'
  },
  educacao: {
    keywords: ['escola', 'colegio', 'faculdade', 'universidade', 'curso', 'creche', 'autoescola', 'idiomas', 'informatica', 'musica', 'danca', 'arte', 'pre-vestibular', 'cursinho'],
    defaultRadius: 15,
    densityFactor: 0.6,
    expectedLeads: 25,
    strategy: 'safe',
    implicitFilters: { filterPhone: true, ignoreDuplicates: true },
    searchGranularity: 'deep'
  },
  servicos_profissionais: {
    keywords: ['advogado', 'contador', 'imobiliaria', 'seguradora', 'banco', 'cartorio', 'despachante', 'consultoria', 'grafica', 'fotografo', 'arquiteto', 'engenheiro', 'tradutor', 'coach', 'rh', 'agencia'],
    defaultRadius: 15,
    densityFactor: 0.7,
    expectedLeads: 30,
    strategy: 'safe',
    implicitFilters: { filterPhone: true, filterWebsite: false, ignoreDuplicates: true },
    searchGranularity: 'deep'
  },
  comercio: {
    keywords: ['loja', 'boutique', 'moda', 'eletronicos', 'moveis', 'decoracao', 'material de construcao', 'ferragem', 'brinquedos', 'livraria', 'papelaria', 'suplementos', 'joalheria', 'relojoaria', 'cosmeticos', 'bebidas', 'atacado', 'celular', 'informatica'],
    defaultRadius: 10,
    densityFactor: 1.0,
    expectedLeads: 40,
    strategy: 'balanced',
    implicitFilters: { filterPhone: true, ignoreDuplicates: true },
    searchGranularity: 'medium'
  },
  automotivo: {
    keywords: ['oficina', 'mecanico', 'borracharia', 'lava jato', 'funilaria', 'eletrica automotiva', 'concessionaria', 'autopecas', 'posto', 'estacionamento', 'locadora', 'guincho', 'insulfilm', 'som automotivo'],
    defaultRadius: 15,
    densityFactor: 0.9,
    expectedLeads: 35,
    strategy: 'balanced',
    implicitFilters: { filterPhone: true, ignoreDuplicates: true },
    searchGranularity: 'medium'
  },
  construcao: {
    keywords: ['construtora', 'empreiteira', 'pintor', 'eletricista', 'encanador', 'marceneiro', 'serralheiro', 'vidracaria', 'dedetizadora', 'limpeza', 'jardinagem', 'seguranca eletronica', 'ar condicionado', 'chaveiro', 'desentupidora'],
    defaultRadius: 20,
    densityFactor: 0.8,
    expectedLeads: 30,
    strategy: 'balanced',
    implicitFilters: { filterPhone: true, ignoreDuplicates: true },
    searchGranularity: 'medium'
  },
  hospedagem: {
    keywords: ['hotel', 'pousada', 'hostel', 'resort', 'motel', 'camping', 'airbnb', 'flat', 'apart-hotel', 'chalé', 'cabana'],
    defaultRadius: 30,
    densityFactor: 0.5,
    expectedLeads: 20,
    strategy: 'safe',
    implicitFilters: { filterPhone: true, ignoreDuplicates: true, minRating: 3.0 },
    searchGranularity: 'deep'
  },
  tecnologia: {
    keywords: ['software', 'sistemas', 'suporte', 'helpdesk', 'internet', 'seguranca da informacao', 'e-commerce', 'aplicativo', 'ia', 'cloud', 'devops', 'seo', 'marketing digital'],
    defaultRadius: 20,
    densityFactor: 0.6,
    expectedLeads: 25,
    strategy: 'safe',
    implicitFilters: { filterPhone: false, filterWebsite: true, ignoreDuplicates: true },
    searchGranularity: 'deep'
  }
};

// ============================================================
// FUNÇÕES AUXILIARES
// ============================================================

/**
 * Normaliza string para comparação
 * @param {string} s
 * @returns {string}
 */
function normalize(s) {
  return s.toLowerCase().normalize('NFD').replace(/[\u0300-\u036f]/g, '');
}

/**
 * Classifica o porte da cidade
 * @param {string} city - Nome da cidade
 * @returns {'capital'|'grande'|'media'|'pequena'}
 */
function classifyCity(city) {
  if (!city) return 'media';
  const cityNorm = normalize(city);

  // Verificar capitais estaduais
  const capitais = new Set([
    'são paulo', 'rio de janeiro', 'brasília', 'salvador', 'fortaleza',
    'belo horizonte', 'manaus', 'curitiba', 'recife', 'porto alegre',
    'belém', 'goiânia', 'são luís', 'maceió', 'natal', 'teresina',
    'campo grande', 'joão pessoa', 'aracaju', 'cuiabá', 'florianópolis',
    'porto velho', 'boa vista', 'macapá', 'palmas', 'vitória', 'rio branco'
  ]);

  for (const cap of capitais) {
    if (normalize(cap) === cityNorm) return 'capital';
  }

  for (const gc of GRANDES_CIDADES) {
    if (normalize(gc) === cityNorm) return 'grande';
  }

  for (const cm of CIDADES_MEDIAS) {
    if (normalize(cm) === cityNorm) return 'media';
  }

  return 'pequena';
}

/**
 * Detecta o perfil de categoria com base no texto digitado
 * @param {string} category - Categoria digitada
 * @returns {string} Nome do perfil
 */
function detectCategoryProfile(category) {
  if (!category) return 'comercio';
  const catNorm = normalize(category);

  let bestProfile = 'comercio';
  let bestScore = 0;

  for (const [profileName, profile] of Object.entries(CATEGORY_PROFILES)) {
    for (const keyword of profile.keywords) {
      if (catNorm.includes(normalize(keyword)) || normalize(keyword).includes(catNorm)) {
        const score = keyword.length; // Priorizar keywords mais específicas
        if (score > bestScore) {
          bestScore = score;
          bestProfile = profileName;
        }
      }
    }
  }

  return bestProfile;
}

// ============================================================
// API PÚBLICA DO AUTO MODE
// ============================================================

/**
 * Calcula os parâmetros ideais de busca automaticamente
 * @param {Object} params
 * @param {string} params.category - Categoria a buscar
 * @param {string} params.city - Cidade alvo
 * @param {string} params.state - Estado (UF)
 * @param {Object} [params.systemInfo] - Informações do sistema (hardware)
 * @param {Object} [params.history] - Histórico de extrações anteriores
 * @returns {AutoModeResult}
 */
export function calculateAutoParams({ category, city, state, systemInfo = null, history = null }) {
  const citySize = classifyCity(city);
  const profileName = detectCategoryProfile(category);
  const profile = CATEGORY_PROFILES[profileName] || CATEGORY_PROFILES.comercio;

  // ---- Raio ideal ----
  let radius = profile.defaultRadius;
  if (citySize === 'capital') {
    radius = Math.max(3, Math.round(profile.defaultRadius * 0.4));
  } else if (citySize === 'grande') {
    radius = Math.max(5, Math.round(profile.defaultRadius * 0.6));
  } else if (citySize === 'media') {
    radius = profile.defaultRadius;
  } else {
    // Cidade pequena: raio maior para capturar mais resultados
    radius = Math.round(profile.defaultRadius * 1.5);
  }

  // ---- Volume de resultados ----
  let maxLeads = profile.expectedLeads;
  if (citySize === 'capital') {
    maxLeads = Math.round(profile.expectedLeads * 2.0);
  } else if (citySize === 'grande') {
    maxLeads = Math.round(profile.expectedLeads * 1.5);
  } else if (citySize === 'pequena') {
    maxLeads = Math.round(profile.expectedLeads * 0.5);
  }

  // Limitar ao máximo razoável
  maxLeads = Math.min(maxLeads, 200);
  maxLeads = Math.max(maxLeads, 10);

  // ---- Estratégia de extração ----
  let strategy = profile.strategy;

  // Ajustar estratégia com base no hardware (se disponível)
  if (systemInfo) {
    if (systemInfo.memoryGB && systemInfo.memoryGB < 4) {
      strategy = 'safe'; // Pouca memória: modo seguro
    } else if (systemInfo.memoryGB && systemInfo.memoryGB >= 16) {
      if (strategy === 'balanced') strategy = 'aggressive';
    }
  }

  // ---- Delays baseados na estratégia ----
  const strategyDelays = {
    safe:       { min: 4.0, max: 8.0 },
    balanced:   { min: 2.0, max: 5.0 },
    aggressive: { min: 0.5, max: 2.0 }
  };
  const delays = strategyDelays[strategy] || strategyDelays.balanced;

  // ---- Filtros implícitos ----
  const implicitFilters = { ...profile.implicitFilters };

  // Ajustar filtros com base no histórico
  if (history && history.length > 0) {
    const avgLeads = history.reduce((sum, h) => sum + (h.count || 0), 0) / history.length;
    if (avgLeads < 5) {
      // Poucas extrações anteriores: relaxar filtros
      implicitFilters.filterPhone = false;
      implicitFilters.minRating = 0;
    }
  }

  // ---- Granularidade da busca ----
  const granularity = profile.searchGranularity;
  const maxScrollAttempts = granularity === 'deep' ? 80 : granularity === 'medium' ? 50 : 30;

  // ---- Construir query otimizada ----
  const queryVariants = buildQueryVariants(category, city, state, radius);

  return {
    // Parâmetros calculados
    radius,
    maxLeads,
    strategy,
    delays,
    implicitFilters,
    maxScrollAttempts,
    granularity,
    queryVariants,

    // Metadados para exibição
    meta: {
      citySize,
      profileName,
      profileLabel: getProfileLabel(profileName),
      reasoning: buildReasoning({ citySize, profileName, radius, maxLeads, strategy, granularity })
    }
  };
}

/**
 * Constrói variantes de query para busca mais abrangente
 * @param {string} category
 * @param {string} city
 * @param {string} state
 * @param {number} radius
 * @returns {string[]}
 */
function buildQueryVariants(category, city, state, radius) {
  const variants = [];

  // Query principal
  variants.push(`${category} em ${city}, ${state}`);

  // Com raio
  if (radius > 0) {
    variants.push(`${category} num raio de ${radius}km de ${city}, ${state}`);
  }

  // Variante sem estado (para cidades únicas)
  variants.push(`${category} ${city}`);

  return variants;
}

/**
 * Retorna o label amigável do perfil
 * @param {string} profileName
 * @returns {string}
 */
function getProfileLabel(profileName) {
  const labels = {
    alimentacao:             'Alimentação',
    saude:                   'Saúde',
    beleza:                  'Beleza',
    educacao:                'Educação',
    servicos_profissionais:  'Serviços Profissionais',
    comercio:                'Comércio',
    automotivo:              'Automotivo',
    construcao:              'Construção',
    hospedagem:              'Hospedagem',
    tecnologia:              'Tecnologia'
  };
  return labels[profileName] || 'Geral';
}

/**
 * Constrói o texto de raciocínio do Auto Mode para exibição ao usuário
 */
function buildReasoning({ citySize, profileName, radius, maxLeads, strategy, granularity }) {
  const citySizeLabels = {
    capital: 'capital estadual',
    grande:  'cidade grande',
    media:   'cidade média',
    pequena: 'cidade pequena'
  };

  const strategyLabels = {
    safe:       'Seguro (anti-bloqueio máximo)',
    balanced:   'Balanceado (recomendado)',
    aggressive: 'Agressivo (máxima velocidade)'
  };

  const granularityLabels = {
    fast:   'rápida',
    medium: 'padrão',
    deep:   'profunda'
  };

  return [
    `Cidade classificada como ${citySizeLabels[citySize] || 'cidade'}`,
    `Categoria: ${getProfileLabel(profileName)}`,
    `Raio sugerido: ${radius} km`,
    `Meta de leads: ${maxLeads}`,
    `Modo: ${strategyLabels[strategy] || strategy}`,
    `Varredura: ${granularityLabels[granularity] || granularity}`
  ];
}

/**
 * Aplica os parâmetros do Auto Mode nos campos do formulário
 * @param {AutoModeResult} autoParams - Resultado de calculateAutoParams
 * @param {Object} elements - Referências aos elementos DOM
 */
export function applyAutoParams(autoParams, elements) {
  const {
    radius, maxLeads, strategy, delays, implicitFilters, maxScrollAttempts
  } = autoParams;

  // Aplicar raio
  if (elements.searchRadiusSelect) {
    const radiusOptions = ['1', '2', '5', '10', '20', '50'];
    const closestRadius = radiusOptions.reduce((prev, curr) =>
      Math.abs(parseInt(curr) - radius) < Math.abs(parseInt(prev) - radius) ? curr : prev
    );
    elements.searchRadiusSelect.value = closestRadius;

    // Se o raio exato não está nas opções, usar personalizado
    if (!radiusOptions.includes(String(radius))) {
      elements.searchRadiusSelect.value = 'custom';
      if (elements.customRadiusInput) {
        elements.customRadiusInput.value = radius;
        if (elements.customRadiusWrapper) {
          elements.customRadiusWrapper.classList.remove('hidden');
        }
      }
    }
  }

  // Aplicar max leads
  if (elements.maxLeadsInput) {
    elements.maxLeadsInput.value = maxLeads;
  }

  // Aplicar estratégia (modo de velocidade)
  if (elements.speedBtns) {
    elements.speedBtns.forEach(btn => {
      btn.classList.toggle('active', btn.getAttribute('data-mode') === strategy);
    });
  }

  // Aplicar delays
  if (elements.delayMinInput) elements.delayMinInput.value = delays.min;
  if (elements.delayMaxInput) elements.delayMaxInput.value = delays.max;

  // Aplicar filtros implícitos
  if (elements.filterPhone && implicitFilters.filterPhone !== undefined) {
    elements.filterPhone.checked = implicitFilters.filterPhone;
  }
  if (elements.ignoreDuplicates && implicitFilters.ignoreDuplicates !== undefined) {
    elements.ignoreDuplicates.checked = implicitFilters.ignoreDuplicates;
  }
  if (elements.minRatingInput && implicitFilters.minRating !== undefined) {
    elements.minRatingInput.value = implicitFilters.minRating;
  }
  if (elements.filterWebsite && implicitFilters.filterWebsite !== undefined) {
    elements.filterWebsite.checked = implicitFilters.filterWebsite;
  }
}

/**
 * Gera o texto de resumo do Auto Mode para exibição no tooltip/painel
 * @param {AutoModeResult} autoParams
 * @returns {string}
 */
export function getAutoModeSummary(autoParams) {
  const { radius, maxLeads, strategy, meta } = autoParams;
  const strategyEmoji = { safe: '🟢', balanced: '🟡', aggressive: '🔴' };

  return [
    `🤖 Auto Mode Ativado`,
    `📍 ${meta.profileLabel} em ${meta.citySize === 'capital' ? 'capital' : meta.citySize === 'grande' ? 'cidade grande' : meta.citySize === 'media' ? 'cidade média' : 'cidade pequena'}`,
    `📏 Raio: ${radius} km`,
    `🎯 Meta: ${maxLeads} leads`,
    `${strategyEmoji[strategy] || '🟡'} Modo: ${strategy === 'safe' ? 'Seguro' : strategy === 'balanced' ? 'Balanceado' : 'Agressivo'}`
  ].join('\n');
}

export default {
  calculateAutoParams,
  applyAutoParams,
  getAutoModeSummary,
  classifyCity,
  detectCategoryProfile
};
