(() => {
  'use strict';
  const KEY = 'm2y_enhancement_popup';
  const fallback = { favorites: [], history: [], theme: 'light', last: null, notices: [] };
  const api = {
    async get() {
      try {
        if (globalThis.chrome?.storage?.local) return { ...fallback, ...(await chrome.storage.local.get(KEY))[KEY] };
      } catch (_) {}
      try { return { ...fallback, ...(JSON.parse(localStorage.getItem(KEY) || '{}')) }; } catch (_) { return { ...fallback }; }
    },
    async set(value) {
      try { if (globalThis.chrome?.storage?.local) return chrome.storage.local.set({ [KEY]: value }); } catch (_) {}
      try { localStorage.setItem(KEY, JSON.stringify(value)); } catch (_) {}
    }
  };
  const qs = (s) => document.querySelector(s);
  const esc = (v) => String(v ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const read = () => ({ category: qs('#category')?.value?.trim() || '', city: qs('#city')?.value?.trim() || '', state: qs('#state')?.value || '', radius: qs('#searchRadius')?.value || '', maxLeads: qs('#maxLeads')?.value || '' });
  const announce = (text) => { const live = qs('#m2yPopupLive'); if (live) live.textContent = text; };
  function renderSummary(state) {
    const box = qs('#m2yPopupEnhancements'); if (!box) return;
    const current = read(); const filled = Object.values(current).filter(Boolean).length;
    const last = state.last;
    const lastText = last ? `${esc(last.category || 'Busca livre')} · ${esc(last.city || 'Sem cidade')} · ${new Date(last.at).toLocaleString('pt-BR', { dateStyle: 'short', timeStyle: 'short' })}` : 'Nenhuma busca registrada.';
    box.innerHTML = `<div class="m2y-essential-summary"><div class="m2y-essential-field"><span>Campos preenchidos</span><strong id="m2yFieldCount">${filled}/6</strong></div><div class="m2y-last-essential">Última busca: <b>${lastText}</b></div></div>`;
    update();
  }

  function toast(text) { const el = qs('#m2yNotice'); if (el) { el.textContent = text; el.classList.add('show'); setTimeout(() => el.classList.remove('show'), 2600); } announce(text); }
  function update() { const q = read(); const n = Object.values(q).filter(Boolean).length; if (qs('#m2yFieldCount')) qs('#m2yFieldCount').textContent = `${n}/6`; if (qs('#m2yReadiness')) qs('#m2yReadiness').textContent = n >= 2 ? 'Pronto para validar' : 'Preencha a consulta principal'; }
  async function init() {
    const state = await api.get();
    const header = document.querySelector('header'); if (!header || qs('#m2yPopupEnhancements')) return;
    const box = document.createElement('section'); box.id = 'm2yPopupEnhancements'; box.className = 'm2y-enhancement-card'; header.insertAdjacentElement('afterend', box);
    const live = document.createElement('div'); live.id = 'm2yPopupLive'; live.className = 'sr-only'; live.setAttribute('aria-live','polite'); document.body.appendChild(live);
    document.body.classList.toggle('m2y-theme-dark', state.theme === 'dark'); document.body.classList.toggle('m2y-density-compact', Boolean(state.compact)); renderSummary(state);
    const start = qs('#startBtn'); start?.addEventListener('click', async () => { const q = read(); state.last = { ...q, at: Date.now() }; state.history = [{ ...q, at: Date.now() }, ...state.history].slice(0, 20); await api.set(state); });
    const nav = [...document.querySelectorAll('.tab-btn')];
    const setTabMemory = () => { const active = document.querySelector('.tab-btn.active')?.dataset.tab; if (active) { state.lastTab = active; api.set(state); } };
    nav.forEach((btn, index) => { btn.addEventListener('click', setTabMemory); btn.addEventListener('keydown', e => { if (!['ArrowRight','ArrowLeft','Home','End'].includes(e.key)) return; e.preventDefault(); const next = e.key === 'Home' ? 0 : e.key === 'End' ? nav.length - 1 : (index + (e.key === 'ArrowRight' ? 1 : -1) + nav.length) % nav.length; nav[next].focus(); nav[next].click(); }); });
    if (state.lastTab) document.querySelector(`.tab-btn[data-tab="${state.lastTab}"]`)?.click();
    document.addEventListener('keydown', e => { if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') start?.click(); if (e.key === 'Escape' && document.activeElement?.matches('input')) document.activeElement.blur(); if (e.key === 'Home' && !['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)) document.body.scrollTo({ top: 0, behavior: 'smooth' }); if (e.key === 'End' && !['INPUT','TEXTAREA','SELECT'].includes(document.activeElement?.tagName)) document.body.scrollTo({ top: document.body.scrollHeight, behavior: 'smooth' }); });
  }
  if (document.readyState === 'loading') document.addEventListener('DOMContentLoaded', init); else init();
})();
