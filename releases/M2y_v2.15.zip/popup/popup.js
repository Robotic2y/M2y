/**
 * M2y v2.11 - Popup Controller
 * ============================================================
 * Mantém 100% da arquitetura base + expansões v2.11:
 * - Autocomplete de Cidades com dataset IBGE completo (5.571 municípios)
 *   Busca incremental, case-insensitive, debounce, sem limite estático
 * - Autocomplete de Categorias com busca fuzzy, normalização de acentos
 *   +500 categorias, múltipla seleção, scroll virtual
 * - Modo Auto Inteligente: raio, volume, estratégia e filtros automáticos
 * - Seletor de SO configurável com detecção automática e sugestão por hardware
 * - Sugestão baseada em CPU, RAM, conexão e estabilidade do ambiente
 * ============================================================
 * NÃO foram alterados:
 * - Fluxo de extração (start/pause/resume/stop)
 * - Comunicação com service-worker.js
 * - Estrutura de dados dos leads
 * - Sistema de abas
 * - Exportação CSV/XLSX/TXT
 * - Histórico de categorias
 * - CEP auto-preenchimento
 * - Geolocalização
 */

import citiesModule from '../modules/cities.js';
import categoriesModule from '../modules/categories.js';
import autoModeModule from '../modules/auto-mode.js';
import systemDetector from '../modules/system-detector.js';

document.addEventListener('DOMContentLoaded', async () => {

  // ============================================================
  // REFERÊNCIAS DOM
  // ============================================================
  const categoryInput       = document.getElementById('category');
  const categoryDropdown    = document.getElementById('categoryDropdown');
  const cepInput            = document.getElementById('cep');
  const cepStatus           = document.getElementById('cepStatus');
  const cityInput           = document.getElementById('city');
  const cityDropdown        = document.getElementById('cityDropdown');
  const stateSelect         = document.getElementById('state');
  const searchRadiusSelect  = document.getElementById('searchRadius');
  const customRadiusWrapper = document.getElementById('customRadiusWrapper');
  const customRadiusInput   = document.getElementById('customRadius');
  const clearCategoryBtn    = document.getElementById('clearCategory');
  const detectLocationBtn   = document.getElementById('detectLocation');
  const categoryHistory     = document.getElementById('categoryHistory');
  const ibgeDatasetInfo     = document.getElementById('ibgeDatasetInfo');
  const freeSearchToggle    = document.getElementById('freeSearchToggle');
  const freeSearchGroup     = document.getElementById('freeSearchGroup');
  const freeSearchInput     = document.getElementById('freeSearchInput');

  // Auto Mode
  const autoModeToggle      = document.getElementById('autoModeToggle');
  const autoModeInfo        = document.getElementById('autoModeInfo');
  const radiusGroup         = document.getElementById('radiusGroup');

  // OS Panel (header)
  const systemCheck         = document.getElementById('systemCheck');
  const recoveryNotice      = document.getElementById('recoveryNotice');
  const osPanel             = document.getElementById('osPanel');
  const closOsPanel         = document.getElementById('closOsPanel');
  const osDetected          = document.getElementById('osDetected');
  const osOverrideSelect    = document.getElementById('osOverrideSelect');
  const hwInfo              = document.getElementById('hwInfo');
  const osRecommendation    = document.getElementById('osRecommendation');
  const applyOsPrefs        = document.getElementById('applyOsPrefs');
  const resetOsPrefs        = document.getElementById('resetOsPrefs');

  // OS na aba Config
  const hwSummaryConfig     = document.getElementById('hwSummaryConfig');
  const osOverrideConfig    = document.getElementById('osOverrideConfig');
  const osIconMap = { windows: '../icons/os/windows.png', macos: '../icons/os/macos.png', linux: '../icons/os/linux.png', chromeos: '../icons/os/chromeos.png', android: '../icons/os/android.png' };
  function updateOsIcon(select, icon) {
    if (!select || !icon) return;
    const src = osIconMap[select.value]; icon.classList.toggle('is-hidden', !src); if (src) icon.src = src;
  }
  const hwRecommendation    = document.getElementById('hwRecommendation');

  const startBtn            = document.getElementById('startBtn');
  const pauseBtn            = document.getElementById('pauseBtn');
  const resumeBtn           = document.getElementById('resumeBtn');
  const stopBtn             = document.getElementById('stopBtn');
  const finishedBox         = document.getElementById('finishedBox');
  const statusBadge         = document.getElementById('statusBadge');

  // Config
  const maxLeadsInput       = document.getElementById('maxLeads');
  const minRatingInput      = document.getElementById('minRating');
  const delayMinInput       = document.getElementById('delayMin');
  const delayMaxInput       = document.getElementById('delayMax');
  const filterPhone         = document.getElementById('filterPhone');
  const filterWebsite       = document.getElementById('filterWebsite');
  const ignoreDuplicates    = document.getElementById('ignoreDuplicates');
  const ignoreClosed        = document.getElementById('ignoreClosed');
  const extractReviews      = document.getElementById('extractReviews');
  const extractHours        = document.getElementById('extractHours');
  const extractEmails       = document.getElementById('extractEmails');
  const extractSocial       = document.getElementById('extractSocial');
  const strictQueryMatch    = document.getElementById('strictQueryMatch');
  const autoPauseOnBlock    = document.getElementById('autoPauseOnBlock');
  const stealthMode         = document.getElementById('stealthMode');
  const proxyInput          = document.getElementById('proxyInput');
  const randomUserAgent     = document.getElementById('randomUserAgent');
  const saveConfigBtn       = document.getElementById('saveConfig');
  const undoConfigBtn       = document.getElementById('undoConfig');
  const speedBtns           = document.querySelectorAll('.speed-btn');

  // Progresso
  const progressBar         = document.getElementById('progressBar');
  const progressLabel       = document.getElementById('progressLabel');
  const progressPercent     = document.getElementById('progressPercent');
  const leadCount           = document.getElementById('leadCount');
  const targetCount         = document.getElementById('targetCount');
  const elapsedTime         = document.getElementById('elapsedTime');
  const etaTime             = document.getElementById('etaTime');
  const statusDot           = document.getElementById('statusDot');
  const statusText          = document.getElementById('statusText');
  const miniLog             = document.getElementById('miniLog');
  const errorCount          = document.getElementById('errorCount');
  const extractionHistory   = document.getElementById('extractionHistory');

  // Exportação
  const exportLeadCount     = document.getElementById('exportLeadCount');
  const exportCsvBtn        = document.getElementById('exportCsvPopup');
  const exportXlsxBtn       = document.getElementById('exportXlsxPopup');
  const exportTxtBtn        = document.getElementById('exportTxtPopup');
  const filenamePreview     = document.getElementById('filenamePreview');

  const dashboardBtn        = document.getElementById('dashboardBtn');

  // Estado interno
  let currentLeads          = [];
  let executionStartTime    = null;
  let elapsedTimer          = null;
  let errorCounter          = 0;
  let isPaused              = false;
  let currentQuery          = '';
  let currentCity           = '';
  let savedConfigSnapshot   = null;
  let systemAnalysis        = null;
  let autoModeActive        = false;
  let currentAutoParams     = null;

  // Debounce timers
  let cityDebounceTimer     = null;
  let categoryDebounceTimer = null;
  let cepRequestCounter     = 0;

  // ============================================================
  // SISTEMA DE ABAS
  // ============================================================
  const tabBtns   = document.querySelectorAll('.tab-btn');
  const tabPanels = document.querySelectorAll('.tab-panel');

  tabBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      const target = btn.getAttribute('data-tab');
      tabBtns.forEach(b => { b.classList.remove('active'); b.setAttribute('aria-selected', 'false'); });
      tabPanels.forEach(p => p.classList.remove('active'));
      btn.classList.add('active');
      btn.setAttribute('aria-selected', 'true');
      document.getElementById(`tab-${target}`).classList.add('active');

      if (target === 'export')   refreshExportTab();
      if (target === 'progress') refreshHistoryTab();

      // Fechar dropdowns ao trocar de aba
      hideDropdown(categoryDropdown);
      hideDropdown(cityDropdown);
    });
  });

  // ============================================================
  // VERIFICAÇÃO DE SISTEMA (com detecção de hardware)
  // ============================================================
  async function runSystemCheck() {
    const report = {
      os:        navigator.platform,
      userAgent: navigator.userAgent,
      timestamp: new Date().toISOString(),
      tests:     {}
    };

    try {
      // Comunicação com background
      try {
        const bgResponse = await chrome.runtime.sendMessage({ action: 'ping' });
        report.tests.communication = bgResponse?.success ? 'OK' : 'FAILED';
      } catch (e) {
        report.tests.communication = 'ERROR: ' + e.message;
      }

      // Storage
      try {
        await chrome.storage.local.set({ _test_check: true });
        const testVal = await chrome.storage.local.get('_test_check');
        report.tests.storage = testVal._test_check ? 'OK' : 'FAILED';
        await chrome.storage.local.remove('_test_check');
      } catch (e) {
        report.tests.storage = 'ERROR: ' + e.message;
      }

      // Tab ativa
      try {
        const [tab] = await chrome.tabs.query({ active: true, currentWindow: true });
        if (tab) {
          report.tests.activeTab = 'OK';
          if (tab.url && tab.url.includes('google.com/maps')) {
            try {
              const contentResponse = await chrome.tabs.sendMessage(tab.id, { action: 'ping' });
              report.tests.contentScript = contentResponse?.success ? 'OK' : 'NOT_RESPONDING';
            } catch (e) {
              report.tests.contentScript = 'NOT_INJECTED';
            }
          } else {
            report.tests.contentScript = 'NOT_ON_MAPS';
          }
        } else {
          report.tests.activeTab = 'NO_TAB';
        }
      } catch (e) {
        report.tests.activeTab = 'ERROR: ' + e.message;
      }

      // Permissões
      try {
        const permissions = await chrome.permissions.getAll();
        report.tests.permissions = permissions.permissions.join(', ');
      } catch (e) {
        report.tests.permissions = 'ERROR: ' + e.message;
      }

      // Análise de sistema e hardware
      try {
        systemAnalysis = await systemDetector.analyzeSystem();
        report.tests.hardware = 'OK';
        updateSystemUI(systemAnalysis);
      } catch (e) {
        report.tests.hardware = 'WARN: ' + e.message;
      }

      const hasErrors = Object.values(report.tests).some(v =>
        typeof v === 'string' && (v.includes('ERROR') || v === 'FAILED')
      );

      if (!hasErrors) {
        const osLabel = systemAnalysis
          ? `${systemDetector.OS_LABELS[systemAnalysis.os.os] || systemAnalysis.os.os} (${systemAnalysis.os.arch})`
          : report.os;
        systemCheck.className = 'system-check success';
        systemCheck.innerHTML = `<span class="check-icon">✔</span> ${osLabel} — Score: ${systemAnalysis?.recommendation?.score ?? '?'}/100 <span style="cursor:pointer;text-decoration:underline;margin-left:6px;" id="openOsPanel">⚙️</span>`;
        document.getElementById('openOsPanel')?.addEventListener('click', () => {
          osPanel.classList.toggle('hidden');
        });
      } else {
        systemCheck.className = 'system-check error';
        systemCheck.innerHTML = `<span class="check-icon">⚠</span> Relatório técnico (Clique para ver)`;
        systemCheck.onclick = () => showErrorReport(report);
      }
    } catch (fatalError) {
      systemCheck.className = 'system-check error';
      systemCheck.innerHTML = `<span class="check-icon">⚠</span> Erro fatal na verificação`;
    }
  }

  /**
   * Atualiza a UI com as informações do sistema detectado
   */
  function updateSystemUI(analysis) {
    if (!analysis) return;

    const { os, hardware, recommendation } = analysis;
    const osIcon  = systemDetector.OS_ICONS[os.os] || '💻';
    const osLabel = systemDetector.OS_LABELS[os.os] || os.os;

    // Painel de SO no header
    if (osDetected) {
      osDetected.textContent = `${osIcon} ${osLabel} ${os.version || ''} (${os.arch})`;
    }

    // Informações de hardware no painel
    if (hwInfo) {
      const connInfo = hardware.connection
        ? ` | 🌐 ${hardware.connection.type || 'desconhecida'}`
        : '';
      hwInfo.innerHTML = `
        <div class="hw-info-grid">
          <span>🔲 CPU: <strong>${hardware.cpuCores || '?'} núcleos</strong></span>
          <span>💾 RAM: <strong>~${hardware.memoryGB || '?'} GB</strong></span>
          <span>📊 Score: <strong>${recommendation.score}/100</strong></span>
          <span>🔧 Classe: <strong>${hardware.memoryClass === 'high' ? 'Alto' : hardware.memoryClass === 'mid' ? 'Médio' : 'Básico'}</strong>${connInfo}</span>
        </div>
      `;
    }

    // Recomendação no painel do header
    if (osRecommendation) {
      const modeLabel = { safe: '🟢 Seguro', balanced: '🟡 Balanceado', aggressive: '🔴 Agressivo' };
      const reasons = recommendation.reasons.slice(0, 2).join(' · ');
      const warnings = recommendation.warnings.length > 0
        ? `<div class="os-warning">⚠️ ${recommendation.warnings[0]}</div>`
        : '';
      osRecommendation.innerHTML = `
        <div class="os-rec-label">Recomendação: <strong>${modeLabel[recommendation.speedMode] || recommendation.speedMode}</strong></div>
        ${reasons ? `<div class="os-rec-reason">${reasons}</div>` : ''}
        ${warnings}
        ${recommendation.isOverridden ? '<div class="os-override-badge">⚙️ Override manual ativo</div>' : ''}
      `;
    }

    // Resumo na aba Config
    if (hwSummaryConfig) {
      hwSummaryConfig.innerHTML = `
        <div class="hw-config-row">
          <span>${osIcon} <strong>${osLabel}</strong> ${os.version || ''}</span>
          <span>🔲 ${hardware.cpuCores || '?'} núcleos</span>
          <span>💾 ~${hardware.memoryGB || '?'} GB RAM</span>
          <span>📊 Score: ${recommendation.score}/100</span>
        </div>
      `;
    }

    // Recomendação na aba Config
    if (hwRecommendation) {
      const modeLabel = { safe: '🟢 Seguro', balanced: '🟡 Balanceado', aggressive: '🔴 Agressivo' };
      if (recommendation.reasons.length > 0 || recommendation.warnings.length > 0) {
        hwRecommendation.classList.remove('hidden');
        hwRecommendation.innerHTML = `
          <div class="hw-rec-title">💡 Recomendação: <strong>${modeLabel[recommendation.speedMode] || recommendation.speedMode}</strong></div>
          ${recommendation.reasons.map(r => `<div class="hw-rec-item">✓ ${r}</div>`).join('')}
          ${recommendation.warnings.map(w => `<div class="hw-warn-item">⚠️ ${w}</div>`).join('')}
        `;
      }
    }

    // Sincronizar selects de SO
    if (analysis.savedPrefs?.osOverride) {
      if (osOverrideSelect) osOverrideSelect.value = analysis.savedPrefs.osOverride;
      if (osOverrideConfig) osOverrideConfig.value = analysis.savedPrefs.osOverride;
      updateOsIcon(osOverrideSelect, document.getElementById('osOverrideSelectIcon'));
      updateOsIcon(osOverrideConfig, document.getElementById('osOverrideConfigIcon'));
    }

    // Aplicar modo recomendado automaticamente (se não há override)
    if (!recommendation.isOverridden) {
      speedBtns.forEach(b => {
        b.classList.toggle('active', b.getAttribute('data-mode') === recommendation.speedMode);
      });
      delayMinInput.value = recommendation.delayMin;
      delayMaxInput.value = recommendation.delayMax;
    }
  }

  function showErrorReport(report) {
    const existing = document.querySelector('.error-report');
    if (existing) return existing.remove();
    const div = document.createElement('div');
    div.className = 'error-report';
    div.innerHTML = `
      <h4>Relatório Técnico de Erro</h4>
      <p><strong>OS:</strong> ${report.os}</p>
      <p><strong>Timestamp:</strong> ${report.timestamp}</p>
      <hr>
      <pre>${JSON.stringify(report.tests, null, 2)}</pre>
      <button style="width:100%;padding:8px;margin-top:8px;background:#ef4444;color:white;border:none;border-radius:4px;cursor:pointer;">Fechar</button>
    `;
    div.querySelector('button').onclick = () => div.remove();
    document.body.appendChild(div);
  }

  // ============================================================
  // PAINEL DE SO (header)
  // ============================================================
  if (closOsPanel) {
    closOsPanel.addEventListener('click', () => osPanel.classList.add('hidden'));
  }

  if (applyOsPrefs) {
    applyOsPrefs.addEventListener('click', async () => {
      const osVal = osOverrideSelect?.value || '';
      const prefs = { osOverride: osVal || null };

      // Aplicar modo de velocidade recomendado para o SO
      if (systemAnalysis && !osVal) {
        // Resetar para detecção automática
        const rec = systemAnalysis.recommendation;
        speedBtns.forEach(b => {
          b.classList.toggle('active', b.getAttribute('data-mode') === rec.speedMode);
        });
        delayMinInput.value = rec.delayMin;
        delayMaxInput.value = rec.delayMax;
      }

      await systemDetector.saveSystemPrefs(prefs);
      if (osOverrideConfig) osOverrideConfig.value = osVal;
      updateOsIcon(osOverrideConfig, document.getElementById('osOverrideConfigIcon'));

      applyOsPrefs.textContent = '✅ Aplicado!';
      setTimeout(() => { applyOsPrefs.textContent = '✅ Aplicar'; }, 2000);
      addMiniLog('success', `Preferência de SO salva: ${osVal || 'Automático'}`);
    });
  }

  if (resetOsPrefs) {
    resetOsPrefs.addEventListener('click', async () => {
      await systemDetector.clearSystemPrefs();
      if (osOverrideSelect) osOverrideSelect.value = '';
      if (osOverrideConfig) osOverrideConfig.value = '';
      updateOsIcon(osOverrideSelect, document.getElementById('osOverrideSelectIcon'));
      updateOsIcon(osOverrideConfig, document.getElementById('osOverrideConfigIcon'));
      // Re-executar detecção
      systemAnalysis = await systemDetector.analyzeSystem(false);
      updateSystemUI(systemAnalysis);
      resetOsPrefs.textContent = '✅ Resetado!';
      setTimeout(() => { resetOsPrefs.textContent = '↩ Resetar'; }, 2000);
      addMiniLog('info', 'Preferências de SO resetadas para detecção automática.');
    });
  }

  // Sincronizar os dois selects de SO
  if (osOverrideConfig) {
    osOverrideConfig.addEventListener('change', () => {
      if (osOverrideSelect) osOverrideSelect.value = osOverrideConfig.value;
      updateOsIcon(osOverrideConfig, document.getElementById('osOverrideConfigIcon'));
      updateOsIcon(osOverrideSelect, document.getElementById('osOverrideSelectIcon'));
    });
  }
  if (osOverrideSelect) {
    osOverrideSelect.addEventListener('change', () => {
      if (osOverrideConfig) osOverrideConfig.value = osOverrideSelect.value;
      updateOsIcon(osOverrideSelect, document.getElementById('osOverrideSelectIcon'));
      updateOsIcon(osOverrideConfig, document.getElementById('osOverrideConfigIcon'));
    });
  }
  updateOsIcon(osOverrideSelect, document.getElementById('osOverrideSelectIcon'));
  updateOsIcon(osOverrideConfig, document.getElementById('osOverrideConfigIcon'));

  // BUSCA LIVRE
  freeSearchToggle?.addEventListener('change', () => {
    const active = freeSearchToggle.checked;
    freeSearchGroup?.classList.toggle('hidden', !active);
    categoryInput.disabled = active;
    cityInput.disabled = active;
    stateSelect.disabled = active;
    detectLocationBtn.disabled = active;
    if (active) {
      searchRadiusSelect.value = '';
      customRadiusWrapper.classList.add('hidden');
    }
  });

  // ============================================================
  // MODO AUTO INTELIGENTE
  // ============================================================
  autoModeToggle?.addEventListener('change', () => {
    autoModeActive = autoModeToggle.checked;
    updateAutoModeUI();
  });

  function updateAutoModeUI() {
    if (!autoModeActive) {
      autoModeInfo.classList.add('hidden');
      autoModeInfo.innerHTML = '';
      // Restaurar campos para edição manual
      if (radiusGroup) radiusGroup.style.opacity = '1';
      return;
    }

    // Calcular parâmetros automáticos
    const freeSearch = Boolean(freeSearchToggle?.checked);
    const freeQuery  = freeSearchInput?.value.trim() || '';
    const category = categoryInput.value.trim();
    const city     = cityInput.value.trim();
    const state    = stateSelect.value;

    if (freeSearch) {
      autoModeInfo.classList.remove('hidden');
      autoModeInfo.innerHTML = '<span class="auto-mode-hint-msg">ℹ️ Auto Inteligente usa categoria e cidade; desative-o para usar Busca Livre.</span>';
      return;
    }

    if (!category || !city) {
      autoModeInfo.classList.remove('hidden');
      autoModeInfo.innerHTML = '<span class="auto-mode-hint-msg">ℹ️ Preencha Categoria e Cidade para ativar o Auto Mode</span>';
      return;
    }

    const hwInfo = systemAnalysis?.hardware || null;
    currentAutoParams = autoModeModule.calculateAutoParams({
      category, city, state, systemInfo: hwInfo
    });

    // Aplicar parâmetros automaticamente
    autoModeModule.applyAutoParams(currentAutoParams, {
      searchRadiusSelect,
      customRadiusInput,
      customRadiusWrapper,
      maxLeadsInput,
      speedBtns,
      delayMinInput,
      delayMaxInput,
      filterPhone,
      ignoreDuplicates,
      minRatingInput,
      filterWebsite
    });

    // Exibir resumo
    const { radius, maxLeads, strategy, meta } = currentAutoParams;
    const strategyLabels = { safe: '🟢 Seguro', balanced: '🟡 Balanceado', aggressive: '🔴 Agressivo' };
    autoModeInfo.classList.remove('hidden');
    autoModeInfo.innerHTML = `
      <div class="auto-mode-result">
        <div class="auto-mode-result-title">🤖 Auto Mode Ativado</div>
        <div class="auto-mode-result-grid">
          <span>📍 ${meta.profileLabel}</span>
          <span>📏 Raio: ${radius} km</span>
          <span>🎯 Meta: ${maxLeads} leads</span>
          <span>${strategyLabels[strategy] || strategy}</span>
        </div>
        <div class="auto-mode-reasoning">
          ${meta.reasoning.map(r => `<span>• ${r}</span>`).join('')}
        </div>
      </div>
    `;

    // Desabilitar raio manual quando Auto Mode ativo
    if (radiusGroup) radiusGroup.style.opacity = '0.5';
  }

  // Recalcular Auto Mode quando campos mudam
  categoryInput?.addEventListener('change', () => {
    if (autoModeActive) updateAutoModeUI();
  });
  cityInput?.addEventListener('change', () => {
    if (autoModeActive) updateAutoModeUI();
  });
  stateSelect?.addEventListener('change', () => {
    if (autoModeActive) updateAutoModeUI();
  });

  // ============================================================
  // CARREGAR CONFIGURAÇÕES SALVAS
  // ============================================================
  const { config, lastSearch, advancedConfig, extractionHistoryData } =
    await chrome.storage.local.get(['config', 'lastSearch', 'advancedConfig', 'extractionHistoryData']);

  if (config) {
    maxLeadsInput.value = config.max_leads || 15;
    const delayS = (config.delay_between_requests_ms || 2000) / 1000;
    delayMinInput.value = config.delay_min_s || delayS;
    delayMaxInput.value = config.delay_max_s || (delayS + 3);
  }

  if (advancedConfig) {
    filterPhone.checked      = advancedConfig.filterPhone      ?? true;
    filterWebsite.checked    = advancedConfig.filterWebsite    ?? false;
    ignoreDuplicates.checked = advancedConfig.ignoreDuplicates ?? true;
    ignoreClosed.checked     = advancedConfig.ignoreClosed     ?? false;
    extractReviews.checked   = advancedConfig.extractReviews   ?? true;
    extractHours.checked     = advancedConfig.extractHours     ?? true;
    extractEmails.checked    = advancedConfig.extractEmails    ?? false;
    extractSocial.checked    = advancedConfig.extractSocial    ?? true;
    if (strictQueryMatch) strictQueryMatch.checked = advancedConfig.strictQueryMatch ?? true;
    autoPauseOnBlock.checked = advancedConfig.autoPauseOnBlock ?? true;
    stealthMode.checked      = advancedConfig.stealthMode      ?? true;
    randomUserAgent.checked  = advancedConfig.randomUserAgent  ?? false;
    minRatingInput.value     = advancedConfig.minRating        ?? 0;
    proxyInput.value         = advancedConfig.proxy            ?? '';

    // Modo de velocidade
    const mode = advancedConfig.speedMode || 'balanced';
    speedBtns.forEach(b => {
      b.classList.toggle('active', b.getAttribute('data-mode') === mode);
    });
  }

  if (lastSearch) {
    categoryInput.value = lastSearch.category || '';
    cityInput.value     = lastSearch.city     || '';
    stateSelect.value   = lastSearch.state    || '';
    cepInput.value      = lastSearch.cep      || '';
    currentCity         = lastSearch.city     || '';
    currentQuery        = lastSearch.freeSearch ? (lastSearch.freeQuery || '') : (lastSearch.category || '');
    if (lastSearch.freeSearch && freeSearchToggle) { freeSearchToggle.checked = true; freeSearchToggle.dispatchEvent(new Event('change')); if (freeSearchInput) freeSearchInput.value = lastSearch.freeQuery || ''; }
  }

  // Salvar snapshot inicial das configurações (para Desfazer Alterações)
  captureConfigSnapshot();

  // Histórico de categorias
  renderCategoryHistory();

  // ============================================================
  // PRÉ-CARREGAR DATASET IBGE EM BACKGROUND
  // ============================================================
  citiesModule.preloadCitiesData().then(() => {
    const info = citiesModule.getDatasetInfo();
    if (ibgeDatasetInfo) {
      ibgeDatasetInfo.textContent = `IBGE: ${info.total.toLocaleString('pt-BR')} municípios`;
    }
    addMiniLog('info', `Dataset IBGE carregado: ${info.total} municípios (${info.source})`);
  }).catch(() => {
    if (ibgeDatasetInfo) ibgeDatasetInfo.textContent = 'Fallback ativo';
  });

  // ============================================================
  // VERIFICAÇÃO DE SISTEMA (com hardware)
  // ============================================================
  runSystemCheck();

  // ============================================================
  // SNAPSHOT DE CONFIGURAÇÕES (Desfazer Alterações)
  // ============================================================
  function captureConfigSnapshot() {
    savedConfigSnapshot = {
      maxLeads:         maxLeadsInput.value,
      minRating:        minRatingInput.value,
      delayMin:         delayMinInput.value,
      delayMax:         delayMaxInput.value,
      filterPhone:      filterPhone.checked,
      filterWebsite:    filterWebsite.checked,
      ignoreDuplicates: ignoreDuplicates.checked,
      ignoreClosed:     ignoreClosed.checked,
      extractReviews:   extractReviews.checked,
      extractHours:     extractHours.checked,
      extractEmails:    extractEmails.checked,
      extractSocial:    extractSocial.checked,
      strictQueryMatch: strictQueryMatch?.checked ?? true,
      autoPauseOnBlock: autoPauseOnBlock.checked,
      stealthMode:      stealthMode.checked,
      randomUserAgent:  randomUserAgent.checked,
      proxy:            proxyInput.value,
      speedMode:        document.querySelector('.speed-btn.active')?.getAttribute('data-mode') || 'balanced'
    };
  }

  function restoreConfigSnapshot() {
    const snap = savedConfigSnapshot;
    if (!snap) return;

    maxLeadsInput.value      = snap.maxLeads;
    minRatingInput.value     = snap.minRating;
    delayMinInput.value      = snap.delayMin;
    delayMaxInput.value      = snap.delayMax;
    filterPhone.checked      = snap.filterPhone;
    filterWebsite.checked    = snap.filterWebsite;
    ignoreDuplicates.checked = snap.ignoreDuplicates;
    ignoreClosed.checked     = snap.ignoreClosed;
    extractReviews.checked   = snap.extractReviews;
    extractHours.checked     = snap.extractHours;
    extractEmails.checked    = snap.extractEmails;
    extractSocial.checked    = snap.extractSocial;
    if (strictQueryMatch) strictQueryMatch.checked = snap.strictQueryMatch ?? true;
    autoPauseOnBlock.checked = snap.autoPauseOnBlock;
    stealthMode.checked      = snap.stealthMode;
    randomUserAgent.checked  = snap.randomUserAgent;
    proxyInput.value         = snap.proxy;

    speedBtns.forEach(b => {
      b.classList.toggle('active', b.getAttribute('data-mode') === snap.speedMode);
    });
  }

  // ============================================================
  // HISTÓRICO DE CATEGORIAS
  // ============================================================
  function renderCategoryHistory() {
    const history = JSON.parse(localStorage.getItem('m2y_cat_history') || '[]');
    categoryHistory.innerHTML = '';
    history.slice(0, 6).forEach(cat => {
      const chip = document.createElement('span');
      chip.className = 'history-chip';
      chip.textContent = cat;
      chip.addEventListener('click', () => {
        categoryInput.value = cat;
        currentQuery = cat;
        hideDropdown(categoryDropdown);
        updateFilenamePreview();
        if (autoModeActive) updateAutoModeUI();
      });
      categoryHistory.appendChild(chip);
    });
  }

  function addCategoryToHistory(cat) {
    if (!cat) return;
    let history = JSON.parse(localStorage.getItem('m2y_cat_history') || '[]');
    history = [cat, ...history.filter(c => c !== cat)].slice(0, 10);
    localStorage.setItem('m2y_cat_history', JSON.stringify(history));
    renderCategoryHistory();
  }

  // ============================================================
  // AUTOCOMPLETE GENÉRICO (helper)
  // ============================================================
  let autocompleteActiveIndex = -1;

  function showDropdown(dropdown, items, onSelect) {
    if (!items || items.length === 0) {
      hideDropdown(dropdown);
      return;
    }

    dropdown.innerHTML = '';
    autocompleteActiveIndex = -1;

    // Scroll virtual: renderizar apenas os primeiros 100 itens visíveis
    // (o restante é carregado ao scrollar)
    const MAX_VISIBLE = 100;
    const visibleItems = items.slice(0, MAX_VISIBLE);

    visibleItems.forEach((item, idx) => {
      const div = document.createElement('div');
      div.className = 'autocomplete-item';
      div.textContent = item;
      div.setAttribute('data-idx', idx);

      div.addEventListener('mousedown', (e) => {
        e.preventDefault(); // Evita blur no input
        onSelect(item);
        hideDropdown(dropdown);
      });

      div.addEventListener('mouseenter', () => {
        setActiveItem(dropdown, idx);
      });

      dropdown.appendChild(div);
    });

    // Indicador de mais resultados
    if (items.length > MAX_VISIBLE) {
      const more = document.createElement('div');
      more.className = 'autocomplete-more';
      more.textContent = `+ ${items.length - MAX_VISIBLE} resultados. Refine a busca.`;
      dropdown.appendChild(more);
    }

    dropdown.classList.remove('hidden');
  }

  function hideDropdown(dropdown) {
    if (dropdown) {
      dropdown.classList.add('hidden');
      dropdown.innerHTML = '';
      autocompleteActiveIndex = -1;
    }
  }

  function setActiveItem(dropdown, idx) {
    const items = dropdown.querySelectorAll('.autocomplete-item');
    items.forEach((item, i) => {
      item.classList.toggle('active', i === idx);
    });
    autocompleteActiveIndex = idx;
  }

  function navigateDropdown(dropdown, direction) {
    const items = dropdown.querySelectorAll('.autocomplete-item');
    if (items.length === 0) return null;

    let newIdx = autocompleteActiveIndex + direction;
    if (newIdx < 0) newIdx = items.length - 1;
    if (newIdx >= items.length) newIdx = 0;

    setActiveItem(dropdown, newIdx);

    // Scroll para o item ativo
    items[newIdx]?.scrollIntoView({ block: 'nearest' });
    return items[newIdx]?.textContent || null;
  }

  function getActiveDropdownItem(dropdown) {
    const active = dropdown.querySelector('.autocomplete-item.active');
    return active ? active.textContent : null;
  }

  // ============================================================
  // AUTOCOMPLETE DE CATEGORIA
  // Melhorias v2.11: busca fuzzy, sem limite, debounce
  // ============================================================

  /**
   * Extrai a última categoria sendo digitada (após a última vírgula)
   */
  function getLastCategoryQuery(fullText) {
    const lastCommaIdx = fullText.lastIndexOf(',');
    if (lastCommaIdx === -1) return fullText.trim();
    return fullText.substring(lastCommaIdx + 1).trim();
  }

  /**
   * Reconstrói o texto completo ao selecionar uma sugestão
   */
  function buildCategoryTextWithSelection(fullText, selected) {
    const lastCommaIdx = fullText.lastIndexOf(',');
    if (lastCommaIdx === -1) return selected;
    const beforeLastComma = fullText.substring(0, lastCommaIdx + 1);
    return beforeLastComma + ' ' + selected;
  }

  categoryInput.addEventListener('input', () => {
    const fullText = categoryInput.value;
    const lastQuery = getLastCategoryQuery(fullText);
    currentQuery = fullText.trim();
    updateFilenamePreview();

    // Debounce de 150ms para performance
    clearTimeout(categoryDebounceTimer);
    categoryDebounceTimer = setTimeout(() => {
      if (lastQuery.length >= 1) {
        // Sem limite estático — retornar todos os resultados relevantes
        const suggestions = categoriesModule.searchCategories(lastQuery, 0);
        showDropdown(categoryDropdown, suggestions, (selected) => {
          categoryInput.value = buildCategoryTextWithSelection(fullText, selected);
          currentQuery = categoryInput.value.trim();
          updateFilenamePreview();
          categoryInput.focus();
          categoryInput.setSelectionRange(categoryInput.value.length, categoryInput.value.length);
          if (autoModeActive) updateAutoModeUI();
        });
      } else if (lastQuery.length === 0) {
        // Mostrar categorias populares quando campo vazio
        const popular = categoriesModule.getPopularCategories(16);
        showDropdown(categoryDropdown, popular, (selected) => {
          categoryInput.value = buildCategoryTextWithSelection(fullText, selected);
          currentQuery = categoryInput.value.trim();
          updateFilenamePreview();
          categoryInput.focus();
          categoryInput.setSelectionRange(categoryInput.value.length, categoryInput.value.length);
          if (autoModeActive) updateAutoModeUI();
        });
      } else {
        hideDropdown(categoryDropdown);
      }
    }, 150);
  });

  categoryInput.addEventListener('focus', () => {
    const fullText = categoryInput.value;
    const lastQuery = getLastCategoryQuery(fullText);
    if (lastQuery.length >= 1) {
      const suggestions = categoriesModule.searchCategories(lastQuery, 0);
      showDropdown(categoryDropdown, suggestions, (selected) => {
        categoryInput.value = buildCategoryTextWithSelection(fullText, selected);
        currentQuery = categoryInput.value.trim();
        updateFilenamePreview();
        categoryInput.focus();
        categoryInput.setSelectionRange(categoryInput.value.length, categoryInput.value.length);
        if (autoModeActive) updateAutoModeUI();
      });
    } else {
      // Mostrar categorias populares ao focar com campo vazio
      const popular = categoriesModule.getPopularCategories(16);
      showDropdown(categoryDropdown, popular, (selected) => {
        categoryInput.value = selected;
        currentQuery = selected;
        updateFilenamePreview();
        categoryInput.focus();
        categoryInput.setSelectionRange(categoryInput.value.length, categoryInput.value.length);
        if (autoModeActive) updateAutoModeUI();
      });
    }
  });

  categoryInput.addEventListener('keydown', (e) => {
    const isOpen = !categoryDropdown.classList.contains('hidden');
    const fullText = categoryInput.value;

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (isOpen) {
        const val = navigateDropdown(categoryDropdown, 1);
        if (val) {
          categoryInput.value = buildCategoryTextWithSelection(fullText, val);
          categoryInput.focus();
          categoryInput.setSelectionRange(categoryInput.value.length, categoryInput.value.length);
        }
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (isOpen) {
        const val = navigateDropdown(categoryDropdown, -1);
        if (val) {
          categoryInput.value = buildCategoryTextWithSelection(fullText, val);
          categoryInput.focus();
          categoryInput.setSelectionRange(categoryInput.value.length, categoryInput.value.length);
        }
      }
    } else if (e.key === 'Enter') {
      if (isOpen) {
        const active = getActiveDropdownItem(categoryDropdown);
        if (active) {
          e.preventDefault();
          categoryInput.value = buildCategoryTextWithSelection(fullText, active);
          currentQuery = categoryInput.value.trim();
          hideDropdown(categoryDropdown);
          updateFilenamePreview();
          categoryInput.focus();
          categoryInput.setSelectionRange(categoryInput.value.length, categoryInput.value.length);
          if (autoModeActive) updateAutoModeUI();
          return;
        }
      }
      // Atalho Shift+Enter para múltiplas categorias
      if (e.shiftKey) {
        e.preventDefault();
        const current = categoryInput.value.trim();
        if (current && !current.endsWith(',')) {
          categoryInput.value = current + ', ';
          categoryInput.focus();
          categoryInput.setSelectionRange(categoryInput.value.length, categoryInput.value.length);
        }
      }
    } else if (e.key === 'Escape') {
      hideDropdown(categoryDropdown);
    }
  });

  clearCategoryBtn.addEventListener('click', () => {
    categoryInput.value = '';
    currentQuery = '';
    hideDropdown(categoryDropdown);
    updateFilenamePreview();
    categoryInput.focus();
    if (autoModeActive) updateAutoModeUI();
  });

  categoryInput.addEventListener('blur', () => {
    setTimeout(() => hideDropdown(categoryDropdown), 150);
  });

  // ============================================================
  // FORMATAÇÃO AUTOMÁTICA DE CEP EM TEMPO REAL
  // ============================================================
  cepInput.addEventListener('input', async (e) => {
    let raw = cepInput.value.replace(/\D/g, '');
    if (raw.length > 8) raw = raw.slice(0, 8);

    // Formatar em tempo real
    if (raw.length <= 5) {
      cepInput.value = raw;
    } else {
      cepInput.value = raw.slice(0, 5) + '-' + raw.slice(5);
    }

    // Incrementar contador para evitar race condition
    const requestId = ++cepRequestCounter;

    // Se vazio ou incompleto: limpar campos e resetar estado
    if (raw.length < 8) {
      cityInput.value = '';
      stateSelect.value = '';
      currentCity = '';
      updateCitySuggestions('');
      updateFilenamePreview();
      if (autoModeActive) updateAutoModeUI();
      
      if (raw.length === 0) {
        hideCepStatus();
      } else {
        showCepStatus('typing', '');
      }
      return;
    }

    // CEP completo: buscar
    showCepStatus('loading', '⏳');
    cepInput.classList.add('loading-input');

    try {
      const result = await citiesModule.searchByCEP(raw);
      
      // Ignorar se uma nova requisição já foi iniciada (race condition)
      if (requestId !== cepRequestCounter) return;

      cepInput.classList.remove('loading-input');

      if (result) {
        cityInput.value = result.city;
        stateSelect.value = result.state;
        currentCity = result.city;
        updateCitySuggestions(result.state);
        updateFilenamePreview();
        showCepStatus('valid', '✓');
        addMiniLog('success', `CEP localizado: ${result.city} - ${result.state}`);
        if (autoModeActive) updateAutoModeUI();
      } else {
        showCepStatus('invalid', '✗');
        addMiniLog('warn', 'CEP não encontrado.');
      }
    } catch (err) {
      if (requestId === cepRequestCounter) {
        cepInput.classList.remove('loading-input');
        showCepStatus('invalid', '✗');
      }
    }
  });

  // Ao sair do campo, garantir formatação correta
  cepInput.addEventListener('blur', () => {
    const raw = cepInput.value.replace(/\D/g, '');
    if (raw.length === 8) {
      cepInput.value = raw.slice(0, 5) + '-' + raw.slice(5);
    } else if (raw.length > 0 && raw.length < 8) {
      showCepStatus('invalid', '✗');
    }
  });

  function showCepStatus(type, icon) {
    if (!cepStatus) return;
    cepStatus.textContent = icon;
    cepStatus.className = `cep-status-icon cep-${type}`;
    cepStatus.classList.remove('hidden');
  }

  function hideCepStatus() {
    if (!cepStatus) return;
    cepStatus.classList.add('hidden');
    cepStatus.textContent = '';
    cepStatus.className = 'cep-status-icon hidden';
  }

  // ============================================================
  // AUTOCOMPLETE DE CIDADE
  // Melhorias v2.11: dataset IBGE completo, debounce, sem limite
  // ============================================================
  cityInput.addEventListener('input', () => {
    const query = cityInput.value.trim();
    const state = stateSelect.value || null;
    currentCity = query;
    updateFilenamePreview();

    // Debounce de 200ms para performance com 5.571 municípios
    clearTimeout(cityDebounceTimer);
    cityDebounceTimer = setTimeout(async () => {
      if (query.length >= 1) {
        // Usar versão assíncrona para garantir que o dataset IBGE está carregado
        const suggestions = await citiesModule.searchCitiesAsync(query, state, 0);
        showDropdown(cityDropdown, suggestions, (selected) => {
          cityInput.value = selected;
          currentCity = selected;
          updateFilenamePreview();
          hideDropdown(cityDropdown);
          if (autoModeActive) updateAutoModeUI();
        });
      } else {
        hideDropdown(cityDropdown);
      }
    }, 200);
  });

  cityInput.addEventListener('focus', async () => {
    const query = cityInput.value.trim();
    const state = stateSelect.value || null;
    if (query.length >= 1) {
      const suggestions = await citiesModule.searchCitiesAsync(query, state, 0);
      showDropdown(cityDropdown, suggestions, (selected) => {
        cityInput.value = selected;
        currentCity = selected;
        updateFilenamePreview();
        hideDropdown(cityDropdown);
        if (autoModeActive) updateAutoModeUI();
      });
    } else if (state) {
      // Mostrar cidades do estado selecionado
      const cities = citiesModule.getCitiesByState(state);
      showDropdown(cityDropdown, cities.slice(0, 20), (selected) => {
        cityInput.value = selected;
        currentCity = selected;
        updateFilenamePreview();
        hideDropdown(cityDropdown);
        if (autoModeActive) updateAutoModeUI();
      });
    }
  });

  cityInput.addEventListener('blur', () => {
    setTimeout(() => hideDropdown(cityDropdown), 150);
  });

  cityInput.addEventListener('keydown', (e) => {
    const isOpen = !cityDropdown.classList.contains('hidden');

    if (e.key === 'ArrowDown') {
      e.preventDefault();
      if (isOpen) {
        const val = navigateDropdown(cityDropdown, 1);
        if (val) { cityInput.value = val; currentCity = val; }
      }
    } else if (e.key === 'ArrowUp') {
      e.preventDefault();
      if (isOpen) {
        const val = navigateDropdown(cityDropdown, -1);
        if (val) { cityInput.value = val; currentCity = val; }
      }
    } else if (e.key === 'Enter') {
      if (isOpen) {
        const active = getActiveDropdownItem(cityDropdown);
        if (active) {
          e.preventDefault();
          cityInput.value = active;
          currentCity = active;
          hideDropdown(cityDropdown);
          updateFilenamePreview();
          if (autoModeActive) updateAutoModeUI();
        }
      }
    } else if (e.key === 'Escape') {
      hideDropdown(cityDropdown);
    }
  });

  stateSelect.addEventListener('change', () => {
    const state = stateSelect.value;
    if (state) updateCitySuggestions(state);
    updateFilenamePreview();
    if (autoModeActive) updateAutoModeUI();
  });

  function updateCitySuggestions(state) {
    const cities = citiesModule.getCitiesByState(state);
    // Apenas preenche o dropdown se o campo estiver em foco
    if (document.activeElement === cityInput) {
      showDropdown(cityDropdown, cities.slice(0, 20), (selected) => {
        cityInput.value = selected;
        currentCity = selected;
        updateFilenamePreview();
        hideDropdown(cityDropdown);
        if (autoModeActive) updateAutoModeUI();
      });
    }
  }

  // ============================================================
  // BOTÃO DETECTAR LOCALIZAÇÃO — GPS + fallback por IP + reverse geocoding
  function resetLocationButton() {
    detectLocationBtn.textContent = '📍';
    detectLocationBtn.classList.remove('spinning');
    detectLocationBtn.disabled = false;
  }

  async function fillLocation({ city = '', state = '', cep = '' }, source) {
    if (city) { cityInput.value = city; currentCity = city; }
    if (state && state.length === 2) stateSelect.value = state.toUpperCase();
    const digits = String(cep || '').replace(/\D/g, '');
    if (digits.length === 8) { cepInput.value = digits.slice(0, 5) + '-' + digits.slice(5); showCepStatus('valid', '✓'); }
    updateFilenamePreview();
    if (autoModeActive) updateAutoModeUI();
    if (city || state) addMiniLog('success', 'Localização detectada via ' + source + ': ' + (city || 'cidade não identificada') + ' - ' + (state || 'UF não identificada'));
    return Boolean(city && state);
  }

  async function reverseGeocode(lat, lng) {
    const response = await fetch('https://nominatim.openstreetmap.org/reverse?format=json&lat=' + lat + '&lon=' + lng + '&zoom=10&addressdetails=1', { headers: { 'Accept-Language': 'pt-BR,pt;q=0.9' } });
    if (!response.ok) throw new Error('Serviço de endereço indisponível');
    const addr = (await response.json())?.address || {};
    return { city: addr.city || addr.town || addr.village || addr.municipality || addr.county || '', state: (addr['ISO3166-2-lvl4'] || '').split('-')[1] || addr.state_code || '', cep: addr.postcode || '' };
  }

  async function detectByIP() {
    const response = await fetch('https://ipwho.is/');
    if (!response.ok) throw new Error('Fallback de localização indisponível');
    const data = await response.json();
    if (data.success === false) throw new Error(data.message || 'Localização por IP indisponível');
    return { city: data.city || '', state: data.region_code || data.region || '', cep: '' };
  }

  detectLocationBtn.addEventListener('click', async () => {
    detectLocationBtn.textContent = '⏳'; detectLocationBtn.classList.add('spinning'); detectLocationBtn.disabled = true;
    addMiniLog('info', 'Solicitando localização atual...');
    try {
      let location;
      if (navigator.geolocation) {
        location = await new Promise((resolve, reject) => navigator.geolocation.getCurrentPosition(resolve, reject, { enableHighAccuracy: false, timeout: 15000, maximumAge: 60000 }));
        const address = await reverseGeocode(location.coords.latitude, location.coords.longitude);
        await fillLocation(address, 'GPS');
      } else throw new Error('GPS não suportado');
    } catch (gpsError) {
      addMiniLog('warn', gpsError.code === 1 ? 'Permissão GPS negada; usando localização aproximada por IP.' : 'GPS indisponível; usando localização aproximada por IP.');
      try { await fillLocation(await detectByIP(), 'IP'); }
      catch (ipError) { addMiniLog('error', 'Não foi possível detectar sua localidade. Permita o acesso à localização ou preencha Cidade/Estado manualmente.'); }
    } finally { resetLocationButton(); }
  });

  // RAIO DE BUSCA COM DIGITAÇÃO MANUAL
  // ============================================================
  searchRadiusSelect.addEventListener('change', () => {
    if (searchRadiusSelect.value === 'custom') {
      customRadiusWrapper.classList.remove('hidden');
      customRadiusInput.focus();
    } else {
      customRadiusWrapper.classList.add('hidden');
      customRadiusInput.value = '';
    }
  });

  customRadiusInput.addEventListener('input', () => {
    let val = customRadiusInput.value.replace(/[^0-9]/g, '');
    if (val.startsWith('0') && val.length > 1) val = val.replace(/^0+/, '');
    customRadiusInput.value = val;
  });

  customRadiusInput.addEventListener('blur', () => {
    const val = parseInt(customRadiusInput.value);
    if (val && val > 0 && val <= 500) {
      // Valor válido — manter
    } else if (customRadiusInput.value !== '') {
      customRadiusInput.value = '';
      addMiniLog('warn', 'Raio inválido. Use valores entre 1 e 500 km.');
    }
  });

  /**
   * Obter o valor do raio de busca (select ou digitação manual)
   */
  function getSearchRadius() {
    if (searchRadiusSelect.value === 'custom') {
      const val = parseInt(customRadiusInput.value);
      return (val && val > 0) ? String(val) : '';
    }
    return searchRadiusSelect.value;
  }

  // ============================================================
  // MODO DE VELOCIDADE
  // ============================================================
  speedBtns.forEach(btn => {
    btn.addEventListener('click', () => {
      speedBtns.forEach(b => b.classList.remove('active'));
      btn.classList.add('active');
      const mode = btn.getAttribute('data-mode');
      applySpeedMode(mode);
    });
  });

  function applySpeedMode(mode) {
    const presets = {
      safe:       { min: 4, max: 8 },
      balanced:   { min: 2, max: 5 },
      aggressive: { min: 0.5, max: 2 }
    };
    const preset = presets[mode] || presets.balanced;
    delayMinInput.value = preset.min;
    delayMaxInput.value = preset.max;
  }

  // ============================================================
  // SALVAR CONFIGURAÇÕES
  // ============================================================
  saveConfigBtn.addEventListener('click', async () => {
    const activeSpeedBtn = document.querySelector('.speed-btn.active');
    const speedMode = activeSpeedBtn ? activeSpeedBtn.getAttribute('data-mode') : 'balanced';
    const delayMin = Math.max(0.5, parseFloat(delayMinInput.value) || 2);
    const delayMax = Math.max(delayMin, parseFloat(delayMaxInput.value) || 5);

    const newConfig = {
      max_leads: parseInt(maxLeadsInput.value) || 15,
      delay_between_requests_ms: delayMin * 1000,
      delay_min_s: delayMin,
      delay_max_s: delayMax,
      timeout_ms: 30000,
      max_scroll_attempts: 50,
      queryContext: {
        category: categoryInput.value.trim(),
        city: cityInput.value.trim(),
        state: stateSelect.value,
        radius: getSearchRadius(),
        freeSearch: Boolean(freeSearchToggle?.checked),
        freeQuery: freeSearchInput?.value.trim() || ''
      }
    };

    const newAdvancedConfig = {
      filterPhone:      filterPhone.checked,
      filterWebsite:    filterWebsite.checked,
      ignoreDuplicates: ignoreDuplicates.checked,
      ignoreClosed:     ignoreClosed.checked,
      extractReviews:   extractReviews.checked,
      extractHours:     extractHours.checked,
      extractEmails:    extractEmails.checked,
      extractSocial:    extractSocial.checked,
      strictQueryMatch: strictQueryMatch?.checked ?? true,
      autoPauseOnBlock: autoPauseOnBlock.checked,
      stealthMode:      stealthMode.checked,
      randomUserAgent:  randomUserAgent.checked,
      minRating:        parseFloat(minRatingInput.value) || 0,
      proxy:            proxyInput.value.trim(),
      speedMode
    };

    // Salvar preferência de SO se houver override
    const osOverride = osOverrideConfig?.value || '';
    if (osOverride) {
      await systemDetector.saveSystemPrefs({ osOverride });
    }

    await chrome.storage.local.set({ config: newConfig, advancedConfig: newAdvancedConfig });

    // Atualizar snapshot após salvar
    captureConfigSnapshot();

    saveConfigBtn.textContent = '✅ Salvo!';
    setTimeout(() => { saveConfigBtn.textContent = '💾 Salvar Configurações'; }, 2000);
    addMiniLog('success', 'Configurações salvas com sucesso.');
  });

  // ============================================================
  // DESFAZER ALTERAÇÕES
  // ============================================================
  undoConfigBtn.addEventListener('click', () => {
    if (!savedConfigSnapshot) {
      addMiniLog('warn', 'Nenhuma configuração salva para restaurar. Usando valores padrão.');
      maxLeadsInput.value      = 15;
      minRatingInput.value     = 0;
      delayMinInput.value      = 2;
      delayMaxInput.value      = 5;
      filterPhone.checked      = true;
      filterWebsite.checked    = false;
      ignoreDuplicates.checked = true;
      ignoreClosed.checked     = false;
      extractReviews.checked   = true;
      extractHours.checked     = true;
      extractEmails.checked    = false;
      extractSocial.checked    = true;
      if (strictQueryMatch) strictQueryMatch.checked = true;
      autoPauseOnBlock.checked = true;
      stealthMode.checked      = true;
      randomUserAgent.checked  = false;
      proxyInput.value         = '';
      speedBtns.forEach(b => {
        b.classList.toggle('active', b.getAttribute('data-mode') === 'balanced');
      });
    } else {
      restoreConfigSnapshot();
    }

    undoConfigBtn.textContent = '✅ Restaurado!';
    setTimeout(() => { undoConfigBtn.textContent = '↩ Desfazer Alterações'; }, 2000);
    addMiniLog('info', 'Configurações restauradas ao último estado salvo.');
  });

  // ============================================================
  // VERIFICAR STATUS ATUAL
  // ============================================================
  chrome.runtime.sendMessage({ action: 'getStatus' }, (response) => {
    if (response && response.status === 'running') {
      showRunning(response.count);
    }
    if (response?.recoveryStatus && recoveryNotice) {
      recoveryNotice.classList.remove('hidden');
      recoveryNotice.innerHTML = `<strong>Execução interrompida</strong><span>${response.count || 0} lead(s) preservado(s).</span><div class="recovery-actions"><button type="button" data-recover="continue">Continuar</button><button type="button" data-recover="finish">Finalizar</button><button type="button" data-recover="discard">Descartar estado</button></div>`;
      recoveryNotice.querySelectorAll('[data-recover]').forEach(button => button.addEventListener('click', async () => {
        const action = button.dataset.recover === 'continue' ? 'recoverContinue' : button.dataset.recover === 'finish' ? 'recoverFinish' : 'recoverDiscard';
        const result = await chrome.runtime.sendMessage({ action });
        if (result?.success) { recoveryNotice.classList.add('hidden'); addMiniLog('info', `Recovery: ${button.textContent}.`); }
      }));
    }
  });

  // ============================================================
  // INICIAR EXTRAÇÃO
  // ============================================================
  startBtn.addEventListener('click', async () => {
    const freeSearch = Boolean(freeSearchToggle?.checked);
    const freeQuery  = freeSearchInput?.value.trim() || '';
    const category = categoryInput.value.trim();
    const city     = cityInput.value.trim();
    const state    = stateSelect.value;
    const radius   = autoModeActive && currentAutoParams
      ? String(currentAutoParams.radius)
      : getSearchRadius();

    if (freeSearch ? !freeQuery : (!category || !city || !state)) {
      return alert(freeSearch ? 'Digite uma consulta para a busca livre.' : 'Por favor, preencha Categoria, Cidade e Estado!');
    }

    // Validar CEP se preenchido
    const cepRaw = cepInput.value.replace(/\D/g, '');
    if (cepRaw && cepRaw.length !== 8) {
      return alert('CEP inválido! Use o formato XXXXX-XXX (8 dígitos).');
    }

    // Validar raio personalizado (apenas se não estiver no Auto Mode)
    if (!autoModeActive && searchRadiusSelect.value === 'custom') {
      const customVal = parseInt(customRadiusInput.value);
      if (!customVal || customVal <= 0 || customVal > 500) {
        return alert('Raio personalizado inválido! Use um valor entre 1 e 500 km.');
      }
    }

    if (!freeSearch) addCategoryToHistory(category);
    currentQuery = freeSearch ? freeQuery : category;
    currentCity  = freeSearch ? '' : city;

    // Montagem da query inteligente com suporte a raio de busca
    let query = freeSearch ? freeQuery : `${category} em ${city}, ${state}`;
    if (!freeSearch && radius && radius !== '') query = `${category} num raio de ${radius}km de ${city}, ${state}`;

    const delayMin = parseFloat(delayMinInput.value) || 2;
    const delayMax = parseFloat(delayMaxInput.value) || 5;
    const activeSpeedBtn = document.querySelector('.speed-btn.active');
    const speedMode = activeSpeedBtn ? activeSpeedBtn.getAttribute('data-mode') : 'balanced';

    // Se Auto Mode ativo, usar parâmetros calculados
    const maxLeadsVal = autoModeActive && currentAutoParams
      ? currentAutoParams.maxLeads
      : parseInt(maxLeadsInput.value) || 15;

    const maxScrollAttempts = autoModeActive && currentAutoParams
      ? currentAutoParams.maxScrollAttempts
      : 50;

    const newConfig = {
      max_leads: maxLeadsVal,
      delay_between_requests_ms: delayMin * 1000,
      delay_min_s: delayMin,
      delay_max_s: delayMax,
      timeout_ms: 30000,
      max_scroll_attempts: maxScrollAttempts,
      speedMode,
      queryContext: { category, city, state, radius, freeSearch, freeQuery },
      autoMode: autoModeActive,
      autoModeParams: autoModeActive ? currentAutoParams : null
    };

    const newAdvancedConfig = {
      filterPhone:      filterPhone.checked,
      filterWebsite:    filterWebsite.checked,
      ignoreDuplicates: ignoreDuplicates.checked,
      ignoreClosed:     ignoreClosed.checked,
      extractReviews:   extractReviews.checked,
      extractHours:     extractHours.checked,
      extractEmails:    extractEmails.checked,
      extractSocial:    extractSocial.checked,
      strictQueryMatch: strictQueryMatch?.checked ?? true,
      autoPauseOnBlock: autoPauseOnBlock.checked,
      stealthMode:      stealthMode.checked,
      randomUserAgent:  randomUserAgent.checked,
      minRating:        parseFloat(minRatingInput.value) || 0,
      proxy:            proxyInput.value.trim(),
      speedMode
    };

    // Aplicar filtros implícitos do Auto Mode
    if (autoModeActive && currentAutoParams?.implicitFilters) {
      const f = currentAutoParams.implicitFilters;
      if (f.filterPhone !== undefined) newAdvancedConfig.filterPhone = f.filterPhone;
      if (f.ignoreDuplicates !== undefined) newAdvancedConfig.ignoreDuplicates = f.ignoreDuplicates;
      if (f.minRating !== undefined) newAdvancedConfig.minRating = f.minRating;
      if (f.filterWebsite !== undefined) newAdvancedConfig.filterWebsite = f.filterWebsite;
    }

    await chrome.storage.local.set({
      config: newConfig,
      advancedConfig: newAdvancedConfig,
      lastSearch: { category, city, state, cep: cepInput.value.trim(), freeSearch, freeQuery }
    });

    isPaused = false;
    errorCounter = 0;
    updateFilenamePreview();

    const modeInfo = autoModeActive ? ` [Auto: ${currentAutoParams?.meta?.profileLabel}]` : '';
    chrome.runtime.sendMessage({ action: 'start', query, config: newConfig, advancedConfig: newAdvancedConfig }, (response) => {
      if (response && response.success) {
        showRunning(0);
        addMiniLog('info', `Iniciando: "${query}"${modeInfo}`);
        if (autoModeActive && currentAutoParams) {
          addMiniLog('info', autoModeModule.getAutoModeSummary(currentAutoParams).split('\n').slice(1).join(' | '));
        }
      } else {
        addMiniLog('error', 'Falha ao iniciar extração.');
      }
    });
  });

  // ============================================================
  // PAUSAR / RETOMAR / PARAR
  // ============================================================
  pauseBtn.addEventListener('click', () => {
    isPaused = true;
    chrome.runtime.sendMessage({ action: 'pause' }, () => {
      showPaused();
      addMiniLog('warn', 'Extração pausada pelo usuário.');
    });
  });

  resumeBtn.addEventListener('click', () => {
    isPaused = false;
    chrome.runtime.sendMessage({ action: 'resume' }, () => {
      showRunning(parseInt(leadCount.textContent) || 0);
      addMiniLog('info', 'Extração retomada.');
    });
  });

  stopBtn.addEventListener('click', () => {
    chrome.runtime.sendMessage({ action: 'stop' }, () => {
      showIdle();
      stopElapsedTimer();
      addMiniLog('warn', 'Extração interrompida pelo usuário.');
    });
  });

  dashboardBtn.addEventListener('click', () => {
    chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });
  });

  // ============================================================
  // ESTADOS DA UI
  // ============================================================
  function showRunning(count) {
    startBtn.classList.add('hidden');
    pauseBtn.classList.remove('hidden');
    resumeBtn.classList.add('hidden');
    stopBtn.classList.remove('hidden');
    finishedBox.classList.add('hidden');

    setBadge('running', '● Extraindo');
    setStatusDot('running');
    statusText.textContent = 'Extraindo...';
    targetCount.textContent = maxLeadsInput.value;
    updateProgress(count);
    startElapsedTimer();
  }

  function showPaused() {
    pauseBtn.classList.add('hidden');
    resumeBtn.classList.remove('hidden');
    setBadge('paused', '⏸ Pausado');
    setStatusDot('paused');
    statusText.textContent = 'Pausado';
    stopElapsedTimer();
  }

  function showIdle() {
    startBtn.classList.remove('hidden');
    pauseBtn.classList.add('hidden');
    resumeBtn.classList.add('hidden');
    stopBtn.classList.add('hidden');
    setBadge('idle', '● Aguardando');
    setStatusDot('idle');
    statusText.textContent = 'Aguardando';
    stopElapsedTimer();
  }

  function showBlocked() {
    setBadge('blocked', '🚫 Bloqueado');
    setStatusDot('blocked');
    statusText.textContent = 'Bloqueio detectado!';
    addMiniLog('error', '⚠ Possível bloqueio detectado pelo Google Maps.');
    if (autoPauseOnBlock.checked) {
      isPaused = true;
      showPaused();
      chrome.runtime.sendMessage({ action: 'pause' });
    }
  }

  function setBadge(type, text) {
    statusBadge.className = `badge badge-${type}`;
    statusBadge.textContent = text;
  }

  function setStatusDot(state) {
    statusDot.className = `status-dot ${state}`;
  }

  function updateProgress(count) {
    const max = parseInt(maxLeadsInput.value) || 15;
    const pct = Math.min(Math.round((count / max) * 100), 100);
    progressBar.style.width = `${pct}%`;
    if (progressPercent) progressPercent.textContent = `${pct}%`;
    progressLabel.textContent = `${count} de ${max} leads coletados`;
    leadCount.textContent = count;

    // ETA
    if (executionStartTime && count > 0) {
      const elapsed = (Date.now() - executionStartTime) / 1000;
      const rate = count / elapsed;
      const remaining = max - count;
      const etaSec = rate > 0 ? Math.round(remaining / rate) : 0;
      etaTime.textContent = etaSec > 0 ? formatSeconds(etaSec) : '—';
    }
  }

  // ============================================================
  // TIMER DECORRIDO
  // ============================================================
  function startElapsedTimer() {
    if (elapsedTimer) clearInterval(elapsedTimer);
    executionStartTime = Date.now();
    elapsedTimer = setInterval(() => {
      const sec = Math.round((Date.now() - executionStartTime) / 1000);
      elapsedTime.textContent = formatSeconds(sec);
    }, 1000);
  }

  function stopElapsedTimer() {
    if (elapsedTimer) { clearInterval(elapsedTimer); elapsedTimer = null; }
  }

  function formatSeconds(sec) {
    if (sec < 60) return `${sec}s`;
    const m = Math.floor(sec / 60);
    const s = sec % 60;
    return `${m}m${s.toString().padStart(2, '0')}s`;
  }

  // ============================================================
  // MINI LOG
  // ============================================================
  function addMiniLog(type, message) {
    const line = document.createElement('p');
    line.className = `log-line ${type}`;
    const time = new Date().toLocaleTimeString('pt-BR', { hour: '2-digit', minute: '2-digit', second: '2-digit' });
    line.textContent = `[${time}] ${message}`;
    miniLog.appendChild(line);
    miniLog.scrollTop = miniLog.scrollHeight;

    // Limitar a 50 linhas
    while (miniLog.children.length > 50) {
      miniLog.removeChild(miniLog.firstChild);
    }

    if (type === 'error') {
      errorCounter++;
      errorCount.textContent = `${errorCounter} erro${errorCounter > 1 ? 's' : ''}`;
      errorCount.classList.remove('hidden');
    }
  }

  // ============================================================
  // HISTÓRICO DE EXTRAÇÕES
  // ============================================================
  function refreshHistoryTab() {
    const history = JSON.parse(localStorage.getItem('m2y_extraction_history') || '[]');
    extractionHistory.innerHTML = '';
    if (history.length === 0) {
      extractionHistory.innerHTML = '<p class="empty-msg">Nenhuma extração registrada.</p>';
      return;
    }
    history.slice(0, 10).forEach(item => {
      const div = document.createElement('div');
      div.className = 'history-item';
      div.innerHTML = `
        <span class="hi-query">${item.query}</span>
        <span class="hi-count">${item.count} leads</span>
        <span class="hi-date">${item.date}</span>
      `;
      extractionHistory.appendChild(div);
    });
  }

  function addToExtractionHistory(query, count) {
    let history = JSON.parse(localStorage.getItem('m2y_extraction_history') || '[]');
    history.unshift({
      query,
      count,
      date: new Date().toLocaleDateString('pt-BR')
    });
    history = history.slice(0, 10);
    localStorage.setItem('m2y_extraction_history', JSON.stringify(history));
  }

  // ============================================================
  // ABA EXPORTAÇÃO
  // ============================================================
  async function refreshExportTab() {
    const data = await chrome.storage.local.get(null);
    const allLeads = [];
    Object.keys(data).forEach(key => {
      if (key.startsWith('leads_')) allLeads.push(...data[key]);
    });
    currentLeads = allLeads;
    exportLeadCount.textContent = allLeads.length;
    updateFilenamePreview();
  }

  function updateFilenamePreview() {
    const cat   = (currentQuery || 'leads').replace(/[^a-z0-9áéíóúãõçâêî]/gi, '_').toLowerCase().slice(0, 20);
    const city  = (currentCity || 'cidade').replace(/[^a-z0-9áéíóúãõçâêî]/gi, '_').toLowerCase().slice(0, 15);
    const state = stateSelect.value || 'UF';
    const count = maxLeadsInput.value || '0';
    const date  = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    const name  = `${cat}_${city}_${state}_${count}leads_${date}`;
    const preview = document.querySelector('#filenamePreview em');
    if (preview) preview.textContent = name + '.csv / .xlsx / .txt';
  }

  function getSelectedColumns() {
    return Array.from(document.querySelectorAll('.export-col:checked')).map(c => c.value);
  }

  function buildFilename(ext) {
    const cat   = (currentQuery || 'leads').replace(/[^a-z0-9]/gi, '_').toLowerCase().slice(0, 20);
    const city  = (currentCity || 'cidade').replace(/[^a-z0-9]/gi, '_').toLowerCase().slice(0, 15);
    const state = stateSelect.value || 'UF';
    const count = currentLeads.length;
    const date  = new Date().toISOString().slice(0, 10).replace(/-/g, '');
    return `${cat}_${city}_${state}_${count}leads_${date}.${ext}`;
  }

  const COLUMN_LABELS = {
    name:             'Nome',
    phone:            'Telefone',
    website:          'Website',
    address:          'Endereço',
    city:             'Cidade',
    state:            'Estado',
    category_main:    'Categoria',
    category_macro:   'Macro Categoria',
    rating_formatted: 'Avaliação',
    rating_value:     'Nota',
    reviews_count:    'Avaliações',
    hours:            'Horários',
    social_instagram: 'Instagram',
    social_facebook:  'Facebook',
    digital_presence: 'Presença Digital',
    status:           'Status',
    google_maps_url:  'URL Maps',
    extracted_at:     'Data Extração'
  };

  exportCsvBtn.addEventListener('click', async () => {
    await refreshExportTab();
    if (currentLeads.length === 0) return alert('Nenhum lead disponível para exportar.');
    const cols = getSelectedColumns();
    if (cols.length === 0) return alert('Selecione ao menos uma coluna para exportar.');

    const headers = cols.map(c => COLUMN_LABELS[c] || c);
    const rows = [headers.join(',')];
    currentLeads.forEach(l => {
      const row = cols.map(c => `"${(l[c] || '').toString().replace(/"/g, '""')}"`);
      rows.push(row.join(','));
    });
    const blob = new Blob(['\uFEFF' + rows.join('\n')], { type: 'text/csv;charset=utf-8;' });
    downloadBlob(blob, buildFilename('csv'));
    addMiniLog('success', `CSV exportado: ${currentLeads.length} leads.`);
  });

  exportXlsxBtn.addEventListener('click', async () => {
    await refreshExportTab();
    if (currentLeads.length === 0) return alert('Nenhum lead disponível para exportar.');
    if (typeof XLSX === 'undefined') return alert('Biblioteca XLSX não carregada. Tente pelo Dashboard.');

    const cols = getSelectedColumns();
    if (cols.length === 0) return alert('Selecione ao menos uma coluna para exportar.');

    const headers = cols.map(c => COLUMN_LABELS[c] || c);
    const wsData  = [headers, ...currentLeads.map(l => cols.map(c => l[c] || ''))];
    const ws      = XLSX.utils.aoa_to_sheet(wsData);
    const wb      = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(wb, ws, 'Leads');
    XLSX.writeFile(wb, buildFilename('xlsx'));
    addMiniLog('success', `XLSX exportado: ${currentLeads.length} leads.`);
  });

  exportTxtBtn?.addEventListener('click', async () => {
    await refreshExportTab();
    if (currentLeads.length === 0) return alert('Nenhum lead disponível para exportar.');

    let txt = `M2y v2.11 - RELATÓRIO DE LEADS\n${'='.repeat(50)}\n`;
    txt += `Gerado em: ${new Date().toLocaleString('pt-BR')}\n`;
    txt += `Total de leads: ${currentLeads.length}\n\n`;

    const cols = getSelectedColumns();
    currentLeads.forEach((l, i) => {
      txt += `LEAD #${i + 1}\n${'-'.repeat(30)}\n`;
      cols.forEach(c => {
        txt += `${COLUMN_LABELS[c] || c}: ${l[c] || 'N/A'}\n`;
      });
      txt += '\n';
    });

    const blob = new Blob([txt], { type: 'text/plain;charset=utf-8;' });
    downloadBlob(blob, buildFilename('txt'));
    addMiniLog('success', `TXT exportado: ${currentLeads.length} leads.`);
  });

  function downloadBlob(blob, filename) {
    const url  = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.setAttribute('href', url);
    link.setAttribute('download', filename);
    link.click();
    setTimeout(() => URL.revokeObjectURL(url), 1000);
  }

  // ============================================================
  // LISTENER DE MENSAGENS DO BACKGROUND
  // ============================================================
  chrome.runtime.onMessage.addListener((message) => {
    if (message.action === 'ui_update') {
      updateProgress(message.count);
      addMiniLog('info', `Lead #${message.count} coletado.`);
    } else if (message.action === 'ui_finished') {
      const count = parseInt(leadCount.textContent) || 0;
      addToExtractionHistory(currentQuery || 'Busca', count);
      showIdle();
      stopElapsedTimer();
      finishedBox.classList.remove('hidden');
      setBadge('done', '✔ Concluído');
      setStatusDot('done');
      statusText.textContent = 'Finalizado';
      addMiniLog('success', `Extração concluída: ${count} leads.`);
      setTimeout(() => {
        chrome.tabs.create({ url: chrome.runtime.getURL('dashboard/dashboard.html') });
      }, 3000);
    } else if (message.action === 'ui_blocked') {
      showBlocked();
    } else if (message.action === 'ui_log') {
      addMiniLog(message.logType || 'info', message.text);
    }
  });

  // Fechar dropdowns ao clicar fora
  document.addEventListener('click', (e) => {
    if (!e.target.closest('.autocomplete-wrapper')) {
      hideDropdown(categoryDropdown);
      hideDropdown(cityDropdown);
    }
    // Fechar painel de SO ao clicar fora
    if (osPanel && !osPanel.classList.contains('hidden')) {
      if (!e.target.closest('#osPanel') && !e.target.closest('#openOsPanel') && !e.target.closest('#systemCheck')) {
        osPanel.classList.add('hidden');
      }
    }
  });

  // Inicializar preview do nome do arquivo
  updateFilenamePreview();
  refreshExportTab();
});
